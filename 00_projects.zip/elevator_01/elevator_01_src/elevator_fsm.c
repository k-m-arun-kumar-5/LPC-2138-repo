/* ********************************************************************
FILE                   : elevator_fsm.c

PURPOSE                : Elevator FSM Proc 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 14

*****************************************************************************/
#include "main.h"
#include "appl.h"
#include "elevator_fsm.h"

/* ------------------------------ macro defination ------------------------------ */
typedef enum
{
	NONE_SW_PRESSED_DETECT, ONE_SW_PRESSED_DETECT, AT_LEAST_TWO_SW_PRESSED_DETECT
} switches_pressed_detect_states_t;

/* ----------------------------- global variable defination --------------------- */ 
elevator_ctrl_and_status_t elevator_ctrl_and_status[MAX_NUM_ELEVATORS];

uint8_t limit_sw_arr[MAX_NUM_FLOORS] = 
            {
				LIMIT_SW_FLOOR_0_IO_CH, LIMIT_SW_FLOOR_1_IO_CH, LIMIT_SW_FLOOR_2_IO_CH,
			    LIMIT_SW_FLOOR_3_IO_CH, LIMIT_SW_FLOOR_4_IO_CH
			};
			
uint8_t hall_call_arr[MAX_NUM_FLOORS] = 
            {
				HALL_FLOOR_0_CALL_SW_IO_CH, HALL_FLOOR_1_CALL_SW_IO_CH, HALL_FLOOR_2_CALL_SW_IO_CH,
			    HALL_FLOOR_3_CALL_SW_IO_CH, HALL_FLOOR_4_CALL_SW_IO_CH
			};

uint8_t in_car_call_arr[MAX_NUM_FLOORS] = 
            {
				IN_CAR_CALL_SW_FLOOR_0_IO_CH, IN_CAR_CALL_SW_FLOOR_1_IO_CH, IN_CAR_CALL_SW_FLOOR_2_IO_CH,
				IN_CAR_CALL_SW_FLOOR_3_IO_CH, IN_CAR_CALL_SW_FLOOR_4_IO_CH
			};	
			
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
elevator_fsm_proc_func_t Elevator_FSM_Proc_Func_Ptr[NUM_ELEVATOR_FSM_STATES] = 
         { 
		    FSM_Idle_Proc, FSM_Wait_Till_Start_Oper_Proc, FSM_StartUp_Proc, FSM_Decide_Car_Move_Proc, FSM_Trigger_Move_Up_Proc,
			FSM_Trigger_Move_Down_Proc, FSM_Prepare_To_Move_Proc, FSM_Car_Moving_Proc, FSM_Trigger_Car_Stop_Proc, 
			FSM_Wait_Till_Car_Stopped_Proc, FSM_Prepare_Doors_To_Align_Proc, FSM_Wait_Till_Doors_Aligned_Proc, FSM_Trigger_Door_Open_Proc, 
			FSM_Wait_Till_Door_Start_Open_Proc, FSM_Wait_Till_Door_Opened_Proc, FSM_Prepare_User_Entry_And_Exit_Proc,FSM_User_Entry_And_Exit_Proc, 
			FSM_Prepare_Door_Close_Proc, FSM_Trigger_Door_Close_Proc, FSM_Wait_Till_Door_Start_Close_Proc, FSM_Wait_Till_Door_Closed_Proc,
			FSM_Wait_Till_Doors_Unaligned_Proc, FSM_Compute_Next_Stop_Floor_Proc, FSM_Wait_For_Door_Close_To_Start_Open_Proc, FSM_Abnormal_Event_Proc
		 };

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Idle_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.01  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Idle_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	  
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.01.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	switch(cur_elevator_ptr->before_fsm_state)
	{
		case FSM_IDLE:
		    if((ret_status = Enable_Ext_Interrupt(EMER_CAR_STOP_EXT_INTP_CH_ID) ) != SUCCESS)
			{
			    appl_status_flag = ERR_ENABLE_INTERRUPT;
	            Error_or_Warning_Proc("14.01.01", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
				return SUCCESS;
			}  
           	if((ret_status = SW_Oper(CAR_START_SW_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		    {
			     appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.01.02", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
				return SUCCESS;
		    } 				
			#ifdef TRACE_FLOW 
	           Print("IDLE -> WAIT_FOR_START_OPER \r");
			#endif
			#ifdef TRACE_REQ
			   Print("REQ: Car Start Oper \r");
	       #endif	   
		   cur_elevator_ptr->cur_fsm_state = FSM_WAIT_FOR_START_OPER;		    	   
		break;
        case FSM_ABNORMAL_EVENT:
        break;
        default:
           appl_status_flag = ERR_ELEVATOR_BEFORE_FSM_INVALID;
	       Error_or_Warning_Proc("14.01.03", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;	
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Wait_Till_Start_Oper_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.02  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Start_Oper_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t limit_sw_cur_floor  ;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.02.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
   ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_FOR_START_OPER -> ABNORMAL_EVENT \r");
		      Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.03.02", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	} 
	ret_status = SW_Oper(CAR_START_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	  	case SUCCESS:
	          if((ret_status = SW_Oper(CAR_START_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
	          {
		          appl_status_flag = ERR_DEV_DISABLE_PROC;
	              Error_or_Warning_Proc("14.02.02", ERROR_OCCURED, appl_status_flag);
	               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		           return SUCCESS;
			   }
			   if((ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		       {
			      appl_status_flag = ERR_DEV_ENABLE_PROC;
	              Error_or_Warning_Proc("14.02.03", ERROR_OCCURED, appl_status_flag);
	               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		          return SUCCESS;
		       }   	
		       if((ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		       {
			      appl_status_flag = ERR_DEV_ENABLE_PROC;
	              Error_or_Warning_Proc("14.02.04", ERROR_OCCURED, appl_status_flag);
	              Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		          return SUCCESS;
		       }
		       if((ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		       {
			        appl_status_flag = ERR_DEV_ENABLE_PROC;
	                Error_or_Warning_Proc("14.02.05", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;
		       }			   
		       for( limit_sw_cur_floor = 0; limit_sw_cur_floor < MAX_NUM_FLOORS; ++limit_sw_cur_floor)
	           {
	              if((ret_status = SW_Oper(limit_sw_arr[limit_sw_cur_floor], DEV_ENABLE_OPER)) != SUCCESS)
	              {
	                  appl_status_flag = ERR_DEV_ENABLE_PROC;
	                  Error_or_Warning_Proc("14.02.06", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
		          }				   
	          }
              #ifdef TRACE_FLOW
	            Print("WAIT_FOR_START_OPER -> STARTUP \r");	
			  #endif
              #ifdef TRACE_REQ			  
                Print("REQ: Startup - car floor position \r");			   
	         #endif
	         if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_STARTUP_CUR_FLOOR)) != SUCCESS)
	         {
	            appl_status_flag = ERR_TIMER_RUN_PROC;
	            Error_or_Warning_Proc("14.02.07", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	         }
	         cur_elevator_ptr->cur_fsm_state = FSM_STARTUP;
		    break;
		    case SW_OR_KEY_NOT_PRESSED:
		    break;
		    case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		    case WARN_CUR_DATA_ID_DEV_DISABLED:
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.02.07", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		   // break;
            default:
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.02.08", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
	   }	   
	   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_StartUp_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_StartUp_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t limit_sw_cur_floor, limit_sw_detect_flag = NONE_SW_PRESSED_DETECT, cur_floor, is_sw_pressed_state_align, is_sw_pressed_state_open, is_sw_pressed_state_close;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.03.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;	
	
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("STARTUP -> ABNORMAL_EVENT \r");
		      Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.03.02", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
    ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
    switch(ret_status)
    {
       case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
       break;
	   case TMR_NO_MAX_NUM_TIMEOUT_PROC:
	   case TMR_BEFORE_LAST_TIMEOUT_PROC:
	   case TMR_AT_LAST_TIMEOUT_PROC:
	   break;
	   case TMR_MAX_NUM_TIMEOUT_PROC:
           if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_STARTUP_CUR_FLOOR)
	       {
		      appl_status_flag = ERR_TMR_ID_INVALID;
	          Error_or_Warning_Proc("14.03.03", ERROR_OCCURED, appl_status_flag);
	          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		      return SUCCESS;
	      }				
          #ifdef TRACE_ERROR
	           Print("STARTUP -> ABNORMAL_EVENT \r");
		       Print("ERR: Event - startup cur floor not detected \r");			
		  #endif
		  appl_status_flag = ERR_STARTUP_OPER;
	      Error_or_Warning_Proc("14.03.04", ERROR_OCCURED, appl_status_flag);
          cur_elevator_ptr->elevator_status = ERR_STARTUP_CUR_FLOOR_NOT_DETECT;			
		  cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;            			
          return SUCCESS;			
      //break;
       default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.03.05", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	for(limit_sw_cur_floor = 0; limit_sw_cur_floor < MAX_NUM_FLOORS; ++limit_sw_cur_floor)
	{		
	    ret_status = SW_Oper(limit_sw_arr[limit_sw_cur_floor], DEV_READ_OPER);
	    switch(ret_status)
	    {
	         case SUCCESS:
	            switch(limit_sw_detect_flag)
	            {
                    case NONE_SW_PRESSED_DETECT:
			             limit_sw_detect_flag = ONE_SW_PRESSED_DETECT;             
	    		         cur_floor = limit_sw_cur_floor;
		            break;
                    case ONE_SW_PRESSED_DETECT:
                          limit_sw_detect_flag = AT_LEAST_TWO_SW_PRESSED_DETECT;
			        break;   
			    } 
		     break;
		     case SW_OR_KEY_NOT_PRESSED:
		     break;
		     case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		     case WARN_CUR_DATA_ID_DEV_DISABLED:
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.03.06", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
		    // break;
             default:
               	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.03.07", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	    }
		if((ret_status = Disp_Elevator_Status(ctrl_elevator_ch_id)) != SUCCESS)
	    {
		       appl_status_flag = ERR_ELEVATOR_DISP_PROC;
	           Error_or_Warning_Proc("14.03.08", ERROR_OCCURED, appl_status_flag);
	            #ifdef TRACE_ERROR 
	              Print("STARTUP -> ABNORMAL_EVENT \r");
		          Print("ERR: event - disp status \r");
	          #endif
			  cur_elevator_ptr->elevator_status = ERR_DISP_STATUS;
	          cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			  return SUCCESS;
	     }
	}
	switch(limit_sw_detect_flag)
	{
         case NONE_SW_PRESSED_DETECT:
	         return SUCCESS;
	     // break;
         case ONE_SW_PRESSED_DETECT:
            if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
	        {
	           appl_status_flag = ERR_TIMER_STOP_PROC;
	           Error_or_Warning_Proc("14.03.09", ERROR_OCCURED, appl_status_flag);
	           Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS; 
		    }
            if((ret_status = SW_Oper(USER_BLOCKS_DOOR_SENSOR_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		    {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.10", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }
		     if((ret_status = SW_Oper(MANUAL_DOOR_CTRL_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.11", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }
             if((ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.12", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }	
			 if((ret_status = SW_Oper(MANUAL_DOOR_CLOSE_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.13", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }
             if((ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.14", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }	
			 if((ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.03.15", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }				 
	        cur_elevator_ptr->cur_floor = cur_floor;
            #ifdef TRACE_INFO
		         uint32_temp_disp_data = cur_elevator_ptr->cur_floor;
		         Print("Startup floor car : %u \r", uint32_temp_disp_data );				 			 
            #endif	
			 cur_elevator_ptr->next_stop_floor = DEFAULT_START_FLOOR;			 
			 if((ret_status = SW_Present_State_By_IO_Ch(DOORS_ALIGNED_SW_IO_CH, &is_sw_pressed_state_align)) != SUCCESS)
	         {
	            	appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                Error_or_Warning_Proc("14.03.16", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;   
	         }
			 if((ret_status = SW_Present_State_By_IO_Ch(LIMIT_SW_DOOR_CLOSE_IO_CH, &is_sw_pressed_state_close)) != SUCCESS)
	         {
	             	appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                Error_or_Warning_Proc("14.03.17", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;
	         }
			 if((ret_status = SW_Present_State_By_IO_Ch(LIMIT_SW_DOOR_OPEN_IO_CH, &is_sw_pressed_state_open)) != SUCCESS)
	         {
	             	appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                Error_or_Warning_Proc("14.03.18", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		           return SUCCESS;
	         }
             if(is_sw_pressed_state_close == STATE_YES )
	         {	
	              if(is_sw_pressed_state_open == STATE_YES)
			      {
					   #ifdef TRACE_ERROR
	                      Print("STARTUP -> ABNORMAL_EVENT \r");
	                      Print("ERR: Event - startup door open and close are active \r");
	                   #endif
					   appl_status_flag = ERR_STARTUP_OPER;
	                   Error_or_Warning_Proc("14.03.19", ERROR_OCCURED, appl_status_flag);
	                   cur_elevator_ptr->elevator_status = ERR_STARTUP_DOOR_OPEN_AND_CLOSE_ACTIVE;
	                   cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		               return SUCCESS;
				  }			   
			 }				 
             if(cur_elevator_ptr->cur_floor == cur_elevator_ptr->next_stop_floor)
			 {
				if(is_sw_pressed_state_align == STATE_YES)
	            { 			        
			       if(is_sw_pressed_state_open == STATE_YES)
			       {
					   #ifdef TRACE_FLOW
					      Print("STARTUP -> PREPARE_USER_ENTRY_AND_EXIT \r");	
						#endif
					    cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_USER_ENTRY_AND_EXIT;
				   }
                   else
                   {
					   if(is_sw_pressed_state_close == STATE_YES)
			           {
					         #ifdef TRACE_FLOW
					           Print("STARTUP -> TRIGGER_DOOR_OPEN \r");	
						     #endif
					         cur_elevator_ptr->cur_fsm_state = FSM_TRIGGER_DOOR_OPEN;
				       }
                       else
                       {	
				           if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_HIGH)) != SUCCESS)
	                       {
	                        	appl_status_flag = ERR_IO_CH_WRITE;
	                            Error_or_Warning_Proc("14.03.20", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                       }
	                       if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
	                       {
	                        	appl_status_flag = ERR_IO_CH_WRITE;
	                            Error_or_Warning_Proc("14.03.21", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                       } 
					       if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_OPENED_MOTOR)) != SUCCESS)
	                       {
		                      appl_status_flag = ERR_TIMER_RUN_PROC;
	                          Error_or_Warning_Proc("11.03.22", ERROR_OCCURED, appl_status_flag);
	                          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                      return SUCCESS;
	                       }
		                  #ifdef TRACE_FLOW
	                        Print("STARTUP -> WAIT_TILL_DOOR_OPENED \r");
						  #endif
                          #ifdef TRACE_REQ						 
	                        Print("REQ: Door open limit SW to active \r");
	                      #endif
	                      cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_OPENED;	 
					   }
                   }	
				}
				else
	            { 
			       if(is_sw_pressed_state_open == STATE_YES)
			       {
					    #ifdef TRACE_ERROR
	                      Print("STARTUP -> ABNORMAL_EVENT \r");
	                      Print("ERR: Event - doors unaligned and opened \r");
	                   #endif
					   appl_status_flag = ERR_STARTUP_OPER;
	                   Error_or_Warning_Proc("14.03.23", ERROR_OCCURED, appl_status_flag);
	                   cur_elevator_ptr->elevator_status = ERR_DOORS_UNALIGNED_BUT_OPENED;
	                   cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		               return SUCCESS; 
				   }
                   else
                   {
					    #ifdef TRACE_FLOW
					      Print("STARTUP -> PREPARE_DOORS_TO_ALIGN \r");	
						#endif
					   cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_DOORS_TO_ALIGN;
                   } 
				}				
			 }   			 
             else
			 {
				if(is_sw_pressed_state_align == STATE_YES)
	            { 	
                   if(is_sw_pressed_state_close == STATE_YES)
			       {
					    if((ret_status = Timer_Run(CH_ID_01,TIMER_ID_DOORS_UNALIGNED )) != SUCCESS)
			            {
			            	appl_status_flag = ERR_TIMER_RUN_PROC;
	                        Error_or_Warning_Proc("14.03.24", ERROR_OCCURED, appl_status_flag);
	                        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                    return SUCCESS;
			            }
						#ifdef TRACE_FLOW
					      Print("STARTUP -> WAIT_TILL_DOORS_TO_UNALIGN\r");
						#endif
                        #ifdef TRACE_REQ	
						  Print("REQ: doors align to inactive \r");
						#endif
					    cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOORS_TO_UNALIGN;
				   }
                   else
                   {
					   if(is_sw_pressed_state_open == STATE_YES)
			           {
					        #ifdef TRACE_FLOW
					          Print("STARTUP -> TRIGGER_DOOR_CLOSE\r");	
						    #endif
					        cur_elevator_ptr->cur_fsm_state = FSM_TRIGGER_DOOR_CLOSE; 
				       }
                       else
                       {	
				           if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
	                       {
	                        	appl_status_flag = ERR_IO_CH_WRITE;
	                            Error_or_Warning_Proc("14.03.25", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                       }
	                       if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_HIGH)) != SUCCESS)
	                       {
	                        	appl_status_flag = ERR_IO_CH_WRITE;
	                            Error_or_Warning_Proc("14.03.26", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                       } 
					       if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_CLOSED_MOTOR)) != SUCCESS)
	                       {
		                      appl_status_flag = ERR_TIMER_RUN_PROC;
	                          Error_or_Warning_Proc("14.03.27", ERROR_OCCURED, appl_status_flag);
	                          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                      return SUCCESS;
	                       }
		                  #ifdef TRACE_FLOW
	                        Print("STARTUP -> WAIT_TILL_DOOR_CLOSED \r");
						  #endif
                          #ifdef TRACE_REQ	
	                        Print("REQ: Door close limit SW to active \r");
	                      #endif
	                      cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_CLOSED;	 
					   }
                   }
				}
				else
	            { 
			       if(is_sw_pressed_state_close == STATE_YES)
			       {
					    #ifdef TRACE_FLOW
					      Print("STARTUP -> DECIDE_CAR_MOVEMENT\r");	
						#endif
					    cur_elevator_ptr->cur_fsm_state = FSM_DECIDE_CAR_MOVEMENT;
				   }
                   else
                   {
					   #ifdef TRACE_ERROR
	                      Print("STARTUP -> ABNORMAL_EVENT \r");
	                      Print("ERR: Event - doors unaligned and not closed \r");
	                   #endif
					   appl_status_flag = ERR_STARTUP_OPER;
	                   Error_or_Warning_Proc("14.03.28", ERROR_OCCURED, appl_status_flag);
	                   cur_elevator_ptr->elevator_status = ERR_DOORS_UNALIGNED_BUT_NOT_CLOSED;
	                   cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		               return SUCCESS; 
                   }	
				}
			 }
             cur_elevator_ptr->before_fsm_state = FSM_STARTUP;	
        break;
		case AT_LEAST_TWO_SW_PRESSED_DETECT:
		     if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		     {
		        appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.03.29", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
			 }
		     #ifdef TRACE_ERROR
	           Print("STARTUP -> ABNORMAL_EVENT \r");
	           Print("ERR: Event - floor limit sw detect > 1 startup\r");
	         #endif
			 appl_status_flag = ERR_MORE_THAN_ONE_SW_DETECT;
	         Error_or_Warning_Proc("14.03.30", ERROR_OCCURED, appl_status_flag);
	         cur_elevator_ptr->elevator_status = ERR_STARTUP_AT_LEAST_TWO_LIMIT_SW_DETECT;
	         cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		     return SUCCESS;
		 //break;
		 default:
          	 appl_status_flag = ERR_FORMAT_INVALID;
	         Error_or_Warning_Proc("14.03.31", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Decide_Car_Move_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.04 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Decide_Car_Move_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;	
	uint16_t ret_status;
	uint8_t car_movement_state;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.04.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("DECIDE_CAR_MOVEMENT -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.04.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS; 
	}
  if((ret_status = Car_Movement_Direction(ctrl_elevator_ch_id, cur_elevator_ptr->cur_floor, &car_movement_state)) != SUCCESS)
	{
	    appl_status_flag = ERR_CAR_MOVE_STATE_PROC;
	    Error_or_Warning_Proc("14.04.03", ERROR_OCCURED, appl_status_flag);
	    #ifdef TRACE_ERROR 
	       Print("DECIDE_CAR_MOVEMENT -> ABNORMAL_EVENT \r");
		   Print("ERR: event - Car movement proc \r");
	    #endif
		cur_elevator_ptr->elevator_status = ERR_CAR_MOVEMENT_PROC;
	    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		return SUCCESS;	 
	}
	switch(car_movement_state)
	{
		   case STARTUP_STATIONARY:
		       #ifdef TRACE_FLOW
	              Print("DECIDE_CAR_MOVEMENT -> PREPARE_DOORS_TO_ALIGN \r");	                  
	           #endif			   
			   cur_elevator_ptr->cur_fsm_state =  FSM_PREPARE_DOORS_TO_ALIGN;			 
		   break;
		   case MOVED_DOWN_STATIONARY:
		   case MOVED_UP_STATIONARY:
		       #ifdef TRACE_FLOW
	              Print("DECIDE_CAR_MOVEMENT -> TRIGGER_CAR_STOP \r");	                  
	           #endif
		       cur_elevator_ptr->cur_fsm_state =  FSM_TRIGGER_CAR_STOP;			  
		   break;
           case MOVE_UP:
		       #ifdef TRACE_FLOW
	              Print("DECIDE_CAR_MOVEMENT -> TRIGGER_MOVE_UP \r");	                  
	           #endif 
               cur_elevator_ptr->cur_fsm_state =  FSM_TRIGGER_MOVE_UP;			  
           break;
           case MOVE_DOWN:
		       #ifdef TRACE_FLOW
	              Print("DECIDE_CAR_MOVEMENT -> TRIGGER_MOVE_DOWN \r");	                  
	           #endif 
               cur_elevator_ptr->cur_fsm_state =  FSM_TRIGGER_MOVE_DOWN;			  
           break;
		   default:
              appl_status_flag = ERR_FORMAT_INVALID;
	          Error_or_Warning_Proc("14.04.04", ERROR_OCCURED, appl_status_flag);
	          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		      return SUCCESS;	
	 }
	 cur_elevator_ptr->elevator_status = car_movement_state;	
     return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Trigger_Move_Up_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.05 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Trigger_Move_Up_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.05.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("TRIGGER_MOVE_UP -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.05.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}

	if((ret_status = Check_Move_Condition(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		  appl_status_flag = ERR_CHECK_MOVE;
	      Error_or_Warning_Proc("14.05.03", ERROR_OCCURED, appl_status_flag);
		 cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;		 
		 return SUCCESS; 
	}
	
       if((ret_status = IO_Channel_Write(CAR_DOWN_IO_CH, STATE_LOW)) != SUCCESS)
	   {
		  appl_status_flag = ERR_IO_CH_WRITE;
	      Error_or_Warning_Proc("14.05.04", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;	
	   }
	   if((ret_status = IO_Channel_Write(CAR_UP_IO_CH, STATE_HIGH)) != SUCCESS)
	   {
	      appl_status_flag = ERR_IO_CH_WRITE;
	      Error_or_Warning_Proc("14.05.05", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS; 
	   }	
	   #ifdef TRACE_FLOW
	     Print("TRIGGER_MOVE_UP -> PREPARE_TO_MOVE \r");
	   #endif
	   cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_TO_MOVE;		   
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Trigger_Move_Down_Proc  

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.06 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Trigger_Move_Down_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
		
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.06.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("TRIGGER_MOVE_DOWN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.06.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Move_Condition(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		  appl_status_flag = ERR_CHECK_MOVE;
	      Error_or_Warning_Proc("14.06.03", ERROR_OCCURED, appl_status_flag);
		  cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		  return SUCCESS; 
	}
	   if((ret_status = IO_Channel_Write(CAR_UP_IO_CH, STATE_LOW)) != SUCCESS)
	   {
		   appl_status_flag = ERR_IO_CH_WRITE;
	       Error_or_Warning_Proc("14.06.04", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	   }
	   if((ret_status = IO_Channel_Write(CAR_DOWN_IO_CH, STATE_HIGH)) != SUCCESS)
	   {
		   appl_status_flag = ERR_IO_CH_WRITE;
	       Error_or_Warning_Proc("14.06.05", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	   }		   
	   #ifdef TRACE_FLOW
	      Print("TRIGGER_MOVE_DOWN -> PREPARE_TO_MOVE \r");
	   #endif
	   cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_TO_MOVE;		   
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Prepare_To_Move_Proc  

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.07 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Prepare_To_Move_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	 
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.07.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("PREPARE_TO_MOVE -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.07.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;	
	}
	if(cur_elevator_ptr->before_fsm_state == FSM_PREPARE_USER_ENTRY_AND_EXIT)
	{
		if((ret_status = Validate_Floor(cur_elevator_ptr->cur_floor)) != SUCCESS)
		{
			appl_status_flag = ERR_FLOOR_INVALID;
	        Error_or_Warning_Proc("14.07.04", ERROR_OCCURED, appl_status_flag);
	        #ifdef TRACE_ERROR 
	          Print("PREPARE_TO_MOVE -> ABNORMAL_EVENT \r");
		      Print("ERR: event - Cur floor invalid \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_CUR_FLOOR_INVALID;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
		}
		if((ret_status = SW_Oper(hall_call_arr[cur_elevator_ptr->cur_floor], DEV_ENABLE_OPER)) != SUCCESS)
		{
			appl_status_flag = ERR_DEV_ENABLE_PROC;
	        Error_or_Warning_Proc("14.07.05", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS; 
		}
		if((ret_status = SW_Oper(in_car_call_arr[cur_elevator_ptr->cur_floor], DEV_ENABLE_OPER)) != SUCCESS)
		{
			appl_status_flag = ERR_DEV_ENABLE_PROC;
	        Error_or_Warning_Proc("14.07.06", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
		}
	}
	if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_NEXT_FLOOR)) != SUCCESS)
	{
		appl_status_flag = ERR_TIMER_RUN_PROC;
	    Error_or_Warning_Proc("14.07.07", ERROR_OCCURED, appl_status_flag);
	    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		return SUCCESS; 
	}
	#ifdef TRACE_FLOW
	  Print("PREPARE_TO_MOVE -> MOVING \r");
	#endif
	cur_elevator_ptr->cur_fsm_state = FSM_MOVING;
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Car_Moving_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.08 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Car_Moving_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t car_movement_state, cur_floor, is_sw_pressed_state_floor;
	static uint8_t limit_sw_cur_floor, previous_floor, proc_bit_field = 0;
  
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.08.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("MOVING -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.08.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
    if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
		   Error_or_Warning_Proc("14.08.03", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("PREPARE_TO_MOVE -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS; 
	}
    ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_NEXT_FLOOR)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.08.04", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}			
		    #ifdef TRACE_ERROR
		      Print("MOVING -> ABNORMAL_EVENT \r");			 
		    #endif
			switch(cur_elevator_ptr->elevator_status)
			{
				case  MOVE_UP:
				   if((ret_status = SW_Present_State_By_IO_Ch(limit_sw_arr[previous_floor], &is_sw_pressed_state_floor)) != SUCCESS)
		           {
			          appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                  Error_or_Warning_Proc("14.08.05", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
		           }
		           switch(is_sw_pressed_state_floor)
		           {
				      case STATE_YES:
					     #ifdef TRACE_ERROR
				           Print("ERR: Event - move up but unmoved \r");
				         #endif
            		     cur_elevator_ptr->elevator_status = ERR_MOVE_UP_BUT_UNMOVED; 
				      break;		 
				      case STATE_NO:
					     cur_elevator_ptr->elevator_status = ERR_MOVING_UP_NEXT_FLOOR_NOT_DETECT;
					     for(cur_floor = 0; cur_floor < MAX_NUM_FLOORS; ++cur_floor)
						 {
							 if(cur_floor == previous_floor || cur_floor == limit_sw_cur_floor)
							 {
								 continue;
							 }
					         if((ret_status = SW_Present_State_By_IO_Ch(limit_sw_arr[cur_floor], &is_sw_pressed_state_floor)) != SUCCESS)
		                     {
			                    appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                            Error_or_Warning_Proc("14.08.06", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
		                    }
							switch(is_sw_pressed_state_floor)
							{
								case STATE_YES:
								  cur_elevator_ptr->elevator_status = ERR_MOVE_UP_NEXT_FLOOR_INVALID; 
								break;
								case STATE_NO:
								break;
								default:
				                   appl_status_flag = ERR_FORMAT_INVALID;
	                               Error_or_Warning_Proc("14.08.07", ERROR_OCCURED, appl_status_flag);
	                               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                           return SUCCESS;
							}
							 if(cur_elevator_ptr->elevator_status == ERR_MOVE_UP_NEXT_FLOOR_INVALID)
							 {
								 break;
							 }
						 }
						 switch(cur_elevator_ptr->elevator_status)
						 {
							 case ERR_MOVING_UP_NEXT_FLOOR_NOT_DETECT:
							    #ifdef TRACE_ERROR
				                    Print("ERR: Event - moving up next floor not detected \r");
				                #endif
							 break;
							 case ERR_MOVE_UP_NEXT_FLOOR_INVALID:
							   #ifdef TRACE_ERROR
				                    Print("ERR: Event - moving up next floor invalid \r");
				               #endif
							 break;  
						 }
					  break;
					  default:
				         appl_status_flag = ERR_FORMAT_INVALID;
	                     Error_or_Warning_Proc("14.08.08", ERROR_OCCURED, appl_status_flag);
	                     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                 return SUCCESS;
				   }					
				break;   
				case MOVE_DOWN:
				   if((ret_status = SW_Present_State_By_IO_Ch(limit_sw_arr[previous_floor], &is_sw_pressed_state_floor)) != SUCCESS)
		           {
			          appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                  Error_or_Warning_Proc("14.08.09", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
		           }
		           switch(is_sw_pressed_state_floor)
		           {
				      case STATE_YES:
					     #ifdef TRACE_ERROR
				           Print("ERR: Event - move down but unmoved \r");
				         #endif
            		     cur_elevator_ptr->elevator_status = ERR_MOVE_DOWN_BUT_UNMOVED; 
				      break;		 
				      case STATE_NO:
					     cur_elevator_ptr->elevator_status = ERR_MOVING_DOWN_NEXT_FLOOR_NOT_DETECT;
					     for(cur_floor = 0; cur_floor < MAX_NUM_FLOORS; ++cur_floor)
						 {
							 if(cur_floor == previous_floor || cur_floor == limit_sw_cur_floor)
							 {
								 continue;
							 }
					         if((ret_status = SW_Present_State_By_IO_Ch(limit_sw_arr[cur_floor], &is_sw_pressed_state_floor)) != SUCCESS)
		                     {
			                    appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	                            Error_or_Warning_Proc("14.08.10", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
		                    }
							switch(is_sw_pressed_state_floor)
							{
								case STATE_YES:
								  cur_elevator_ptr->elevator_status = ERR_MOVE_DOWN_NEXT_FLOOR_INVALID; 
								break;
								case STATE_NO:
								break;
								default:
				                   appl_status_flag = ERR_FORMAT_INVALID;
	                               Error_or_Warning_Proc("14.08.11", ERROR_OCCURED, appl_status_flag);
	                               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                           return SUCCESS;
							}
							 if(cur_elevator_ptr->elevator_status == ERR_MOVE_DOWN_NEXT_FLOOR_INVALID)
							 {
								 break;
							 }
						 }
						 switch(cur_elevator_ptr->elevator_status)
						 {
							 case ERR_MOVING_DOWN_NEXT_FLOOR_NOT_DETECT:
							    #ifdef TRACE_ERROR
				                    Print("ERR: Event - moving down next floor not detected \r");
				                #endif
							 break;
							 case ERR_MOVE_DOWN_NEXT_FLOOR_INVALID:
							   #ifdef TRACE_ERROR
				                    Print("ERR: Event - moving down next floor invalid \r");
				               #endif
							 break; 
						 }
					  break;
					  default:
				         appl_status_flag = ERR_FORMAT_INVALID;
	                     Error_or_Warning_Proc("14.08.12", ERROR_OCCURED, appl_status_flag);
	                     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                 return SUCCESS;
				   }		
				   
            	  	 
				break;
				default:
				   appl_status_flag = ERR_FORMAT_INVALID;
	               Error_or_Warning_Proc("14.08.13", ERROR_OCCURED, appl_status_flag);
	               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		           return SUCCESS;
			}
			#ifdef TRACE_ERROR
			   Print("ERR: Event - next floor not detect \r");
			#endif
         	appl_status_flag = ERR_NOT_DETECT;		
	        Error_or_Warning_Proc("14.08.14", ERROR_OCCURED, appl_status_flag);
            cur_elevator_ptr->elevator_status = ERR_NEXT_FLOOR_NOT_DETECT; 			
		    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;  
            return SUCCESS;						
		//break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.08.15", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS; 
	}
	if((ret_status = Check_Move_Condition(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		 appl_status_flag = ERR_CHECK_MOVE;
	     Error_or_Warning_Proc("14.08.16", ERROR_OCCURED, appl_status_flag);	
		 cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		 return SUCCESS; 
	}
	if((ret_status = Delay_Time_Elevator(ctrl_elevator_ch_id, REQ_DELAY_COUNT_SCAN_LIMIT_SW_FLOORS)) != SUCCESS)
	{
	    appl_status_flag = ERR_DELAY_TIME_ELEVATOR_PROC;
	    Error_or_Warning_Proc("14.08.17", ERROR_OCCURED, appl_status_flag);
	    #ifdef TRACE_ERROR 
	         Print("MOVING -> ABNORMAL_EVENT \r");
	         Print("ERR: event - delay time proc \r");
	    #endif
		cur_elevator_ptr->elevator_status = ERR_DELAY_TIME_PROC;
	    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		return SUCCESS;
	}
	if(((proc_bit_field & (1 << 0)) == 0))
	{
	    switch( cur_elevator_ptr->elevator_status)
	    {
	       case MOVE_UP:
	          limit_sw_cur_floor = cur_elevator_ptr->cur_floor + 1; 
		      previous_floor = cur_elevator_ptr->cur_floor;
	       break;
	       case MOVE_DOWN:
	          limit_sw_cur_floor = cur_elevator_ptr->cur_floor - 1; 
		      previous_floor = cur_elevator_ptr->cur_floor;
	       break;
	       default:
	         appl_status_flag = ERR_FORMAT_INVALID;
	         Error_or_Warning_Proc("14.08.18", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
	         return SUCCESS;
	    }	 
	    #ifdef TRACE_INFO
	        uint32_temp_disp_data = limit_sw_cur_floor;
	        Print("Scan Reading floor limit sw: %u \r", uint32_temp_disp_data);
        #endif
		proc_bit_field |= (1 << 0);
	}	
	ret_status = SW_Oper(limit_sw_arr[limit_sw_cur_floor], DEV_READ_OPER);
	switch(ret_status)
	{
	    case SUCCESS:
	       proc_bit_field |= (1 << 1);           
		   proc_bit_field &= ~(1 << 0);
		break;
		case SW_OR_KEY_NOT_PRESSED:
		    proc_bit_field &= ~(1 << 1);  
		break;
		case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		case WARN_CUR_DATA_ID_DEV_DISABLED:
		    proc_bit_field &= ~(1 << 0);
			 proc_bit_field &= ~(1 << 1); 
		   appl_status_flag = ERR_SW_IS_DISABLED;
	       Error_or_Warning_Proc("14.08.19", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
		// break;
        default:
		    proc_bit_field &= ~(1 << 0); 
			proc_bit_field &= ~(1 << 1); 
           	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.08.20", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	}
	if((proc_bit_field & (1 << 1)))
	{			  
	    if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
	    {
			 proc_bit_field &= ~(1 << 1);
			 appl_status_flag = ERR_TIMER_STOP_PROC;
	         Error_or_Warning_Proc("14.08.21", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
	    }
		proc_bit_field |= (1 << 2);
		for(cur_floor = 0; cur_floor < MAX_NUM_FLOORS; ++cur_floor)
		{
			if(cur_floor == limit_sw_cur_floor)
			{
				continue;
			}
		    if((ret_status = SW_Present_State_By_IO_Ch(limit_sw_arr[cur_floor], &is_sw_pressed_state_floor)) != SUCCESS)
		    {
				proc_bit_field &= ~(1 << 1);
				proc_bit_field &= ~(1 << 2);
			    appl_status_flag = ERR_SW_PRESENT_STATE_PROC;
	            Error_or_Warning_Proc("14.08.22", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		    }
		    switch(is_sw_pressed_state_floor)
		    {
		    	case STATE_YES:
				   proc_bit_field &= ~(1 << 1);
				   proc_bit_field &= ~(1 << 2);
			       #ifdef TRACE_ERROR
	                  Print("DECIDE_CAR_MOVEMENT -> ABNORMAL_EVENT \r");
	                  Print("ERR: Event - floor limit sws detect > 1 \r");
		           #endif
			       appl_status_flag = ERR_MORE_THAN_ONE_SW_DETECT;
	               Error_or_Warning_Proc("14.08.23", ERROR_OCCURED, appl_status_flag);
			       cur_elevator_ptr->elevator_status = ERR_AT_LEAST_TWO_LIMIT_SW_DETECT;	   
	               cur_elevator_ptr->cur_fsm_state =  FSM_ABNORMAL_EVENT;		  
			       return SUCCESS;
			  //break;
               case STATE_NO:			    
               break;
			   default:
			       proc_bit_field &= ~(1 << 1);  
			       proc_bit_field &= ~(1 << 2); 
                   appl_status_flag = ERR_FORMAT_INVALID;
	               Error_or_Warning_Proc("14.08.24", ERROR_OCCURED, appl_status_flag);
	               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		           return SUCCESS;  
			}
		}   
    }
	if((proc_bit_field & (1 << 1)) && (proc_bit_field & (1 << 2)))
	{
		proc_bit_field &= ~(1 << 1);  
		proc_bit_field &= ~(1 << 2); 
		cur_elevator_ptr->cur_floor = limit_sw_cur_floor;
	    if((ret_status = Car_Movement_Direction(ctrl_elevator_ch_id, cur_elevator_ptr->cur_floor, &car_movement_state)) != SUCCESS)
		{
		      appl_status_flag = ERR_CAR_MOVE_STATE_PROC;
	          Error_or_Warning_Proc("14.08.25", ERROR_OCCURED, appl_status_flag);
	          #ifdef TRACE_ERROR 
	               Print("MOVING -> ABNORMAL_EVENT \r");
		           Print("ERR: event - car movement proc invalid \r");
	          #endif
		      cur_elevator_ptr->elevator_status = ERR_CAR_MOVEMENT_PROC;
	          cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		      return SUCCESS;	 
	    }
	    switch(car_movement_state)
		{
		      case MOVE_UP:			     
		      case MOVED_UP_STATIONARY:
                   
					 switch(car_movement_state)
					 {
                         case MOVED_UP_STATIONARY:
						   #ifdef TRACE_FLOW
	                           Print("MOVING -> TRIGGER_CAR_STOP \r");	                  
	                       #endif
		                   cur_elevator_ptr->cur_fsm_state =  FSM_TRIGGER_CAR_STOP;
			               cur_elevator_ptr->elevator_status = MOVED_UP_STATIONARY;
						 break;
						 case MOVE_UP:						    
						    if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_NEXT_FLOOR)) != SUCCESS)
	                        {
	                         	appl_status_flag = ERR_TIMER_RUN_PROC;
	                            Error_or_Warning_Proc("14.08.26", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                        } 
						    #ifdef TRACE_INFO
							   uint32_temp_disp_data = cur_elevator_ptr->cur_floor;
	                           Print("TRA: Moving Up non stop - cur_floor: %u, ", uint32_temp_disp_data); 
                               uint32_temp_disp_data = cur_elevator_ptr->next_stop_floor;
							   Print("next_stop : %u\r", uint32_temp_disp_data); 
	                       #endif
						 break;
					 }	
               break;
               case MOVE_DOWN:			     
			   case MOVED_DOWN_STATIONARY:
				  switch(car_movement_state)
				  {
                       case MOVED_DOWN_STATIONARY:
				     	   #ifdef TRACE_FLOW
	                           Print("MOVING -> TRIGGER_CAR_STOP \r");	                  
	                       #endif
		                   cur_elevator_ptr->cur_fsm_state =  FSM_TRIGGER_CAR_STOP;
			               cur_elevator_ptr->elevator_status = MOVED_DOWN_STATIONARY;
					   break;
					   case MOVE_DOWN:						    
                          if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_NEXT_FLOOR)) != SUCCESS)
	                      {
	                        	appl_status_flag = ERR_TIMER_RUN_PROC;
	                            Error_or_Warning_Proc("14.08.27", ERROR_OCCURED, appl_status_flag);
	                            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                        return SUCCESS;
	                      }  						 
					      #ifdef TRACE_INFO
					        uint32_temp_disp_data = cur_elevator_ptr->cur_floor;
	                        Print("TRA: Moving Down non stop, cur_floor: %u, ", uint32_temp_disp_data); 
                            uint32_temp_disp_data = cur_elevator_ptr->next_stop_floor;
						    Print("next_stop : %u\r", uint32_temp_disp_data); 							   
	                     #endif
					  break;
				  }
               break;
			   default:
                  appl_status_flag = ERR_FORMAT_INVALID;
	              Error_or_Warning_Proc("14.08.28", ERROR_OCCURED, appl_status_flag);
	              Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		          return SUCCESS;	
		}
	}    
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Trigger_Car_Stop_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.09 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Trigger_Car_Stop_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	 
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.09.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
  }	
  cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("TRIGGER_CAR_STOP -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.09.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	if((ret_status = IO_Channel_Write(CAR_UP_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.09.03", ERROR_OCCURED, appl_status_flag);
	    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		return SUCCESS; 
	}
	if((ret_status = IO_Channel_Write(CAR_DOWN_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.09.04", ERROR_OCCURED, appl_status_flag);
	    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_MOTOR_STOP_TO_DOOR_OPEN)) != SUCCESS)
	{
		appl_status_flag = ERR_TIMER_RUN_PROC;
	    Error_or_Warning_Proc("14.09.05", ERROR_OCCURED, appl_status_flag);
	    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
    #ifdef TRACE_FLOW
	   Print("TRIGGER_CAR_STOP -> WAIT_TILL_CAR_STOPPED \r");
	#endif
    #ifdef TRACE_REQ	
	   Print("REQ: Wait till car stops \r");
    #endif	
    cur_elevator_ptr->cur_fsm_state =  FSM_WAIT_TILL_CAR_STOPPED;	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Wait_Till_Car_Stopped_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.10 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Car_Stopped_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	 
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.10.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_CAR_STOPPED -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.10.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
		   Error_or_Warning_Proc("14.10.03", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("WAIT_TILL_CAR_STOPPED -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS; 
	}
   	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_MOTOR_STOP_TO_DOOR_OPEN)
			{
				#ifdef TRACE_ERROR
				  uint32_temp_disp_data = retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id;
				  Print("ERR: timer_id : %u", retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id);
				#endif
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.10.04", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			#ifdef TRACE_FLOW
		      Print("WAIT_TILL_CAR_STOPPED -> PREPARE_DOORS_TO_ALIGN \r");			  
		    #endif
			cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_DOORS_TO_ALIGN;            			
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.10.05", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Prepare_Doors_To_Align_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.11

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Prepare_Doors_To_Align_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;	
	uint16_t ret_status;
		
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.11.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;	
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("PREPARE_DOORS_TO_ALIGN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.11.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.22.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("PREPARE_DOORS_TO_ALIGN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS;
	}
	if((ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
	{
	    appl_status_flag = ERR_DEV_ENABLE_PROC;
	    Error_or_Warning_Proc("14.11.04", ERROR_OCCURED, appl_status_flag);
	    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
	    return SUCCESS;
	}
    if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOORS_ALIGNED)) != SUCCESS)
	{
	      appl_status_flag = ERR_TIMER_RUN_PROC;
	      Error_or_Warning_Proc("14.11.05", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
	       return SUCCESS;
	}
	#ifdef TRACE_FLOW 
	       Print("PREPARE_DOORS_TO_ALIGN -> WAIT_TILL_DOORS_ALIGN\r");
	#endif
    #ifdef TRACE_REQ			
	     Print("REQ: Doors align to active \r");
	#endif
	cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOORS_ALIGN; 
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Wait_Till_Doors_Aligned_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.12

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Doors_Aligned_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.12.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;	
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOORS_ALIGN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.12.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.12.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOORS_ALIGN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS;
	}
	proc_bit_field |= (1 << 0);
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.12.07", ERROR_OCCURED, appl_status_flag);
	        #ifdef TRACE_ERROR 
	          Print("WAIT_TILL_DOORS_ALIGN -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS; 
	}
    ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOORS_ALIGNED)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.12.08", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
			}			
		    #ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOORS_ALIGN -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - req doors align but unalign\r");
		    #endif
			appl_status_flag = ERR_SW_IS_INACTIVE;
	        Error_or_Warning_Proc("14.12.09", ERROR_OCCURED, appl_status_flag);
			cur_elevator_ptr->elevator_status = ERR_REQ_DOORS_ALIGN_BUT_UNALIGN;
			cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
            return SUCCESS;			
		//break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.12.10", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	if((proc_bit_field & (1 << 0)))
	{
	    ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	    switch(ret_status)
	    {
		   case SUCCESS:
		     if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		     {
				appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.12.11", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			if((ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		    {
			    appl_status_flag = ERR_DEV_ENABLE_PROC;
	            Error_or_Warning_Proc("14.12.12", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		    }
			if((ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_ENABLE_OPER) ) != SUCCESS)
		    {
			    appl_status_flag = ERR_DEV_ENABLE_PROC;
	            Error_or_Warning_Proc("14.12.13", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		    }
			#ifdef TRACE_FLOW 
			    Print("WAIT_TILL_DOORS_ALIGN -> TRIGGER_DOOR_OPEN \r");
			#endif 
            cur_elevator_ptr->cur_fsm_state = FSM_TRIGGER_DOOR_OPEN;    			
		  break;
		  case SW_OR_KEY_NOT_PRESSED:
		  break;
		  case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		  case WARN_CUR_DATA_ID_DEV_DISABLED:
		    appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.12.14", ERROR_OCCURED, appl_status_flag);
			Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	 
		//  break;
          default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.12.15", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	 
	   }
	}	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Trigger_Door_Open_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.13 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Trigger_Door_Open_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
  
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.13.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
    ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("TRIGGER_DOOR_OPEN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.13.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS; 
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.13.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("TRIGGER_DOOR_OPEN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS;
	}
	proc_bit_field |= (1 << 0);
   if(proc_bit_field == 1)
   {
	  if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	  {
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.13.06", ERROR_OCCURED, appl_status_flag);
	        #ifdef TRACE_ERROR 
	          Print("TRIGGER_DOOR_OPEN -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS; 
	  }
      if((ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
	  {
	     appl_status_flag = ERR_DEV_DISABLE_PROC;
	     Error_or_Warning_Proc("14.13.07", ERROR_OCCURED, appl_status_flag);
	     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	 }
	if((ret_status = SW_Oper(MANUAL_DOOR_CLOSE_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
	{
	     appl_status_flag = ERR_DEV_ENABLE_PROC;
	     Error_or_Warning_Proc("14.13.08", ERROR_OCCURED, appl_status_flag);
	     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		 return SUCCESS;
	}
    ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:
		    if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH , STATE_LOW)) != SUCCESS)
	        {
		        appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.13.09", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        }
	        if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH , STATE_HIGH)) != SUCCESS)
	        {
	        	appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.13.10", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        }
			if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DETECT_DOOR_OPEN)) != SUCCESS)
	        {
		       appl_status_flag = ERR_TIMER_RUN_PROC;
	           Error_or_Warning_Proc("14.13.11", ERROR_OCCURED, appl_status_flag);
	           Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	        }
		    #ifdef TRACE_FLOW
	          Print("TRIGGER_DOOR_OPEN -> WAIT_TILL_DOOR_START_OPEN \r");
			#endif
            #ifdef TRACE_REQ			
	          Print("REQ: Door close limit SW to inactive \r");
	        #endif
	        cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_START_OPEN;	
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
		    #ifdef TRACE_ERROR
	          Print("TRIGGER_DOOR_OPEN -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - Doors not aligned properly \r");
	        #endif
			appl_status_flag = ERR_SW_IS_INACTIVE;
	         Error_or_Warning_Proc("14.13.12", ERROR_OCCURED, appl_status_flag);
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			cur_elevator_ptr->elevator_status = ERR_DOORS_NOT_ALIGNED_PROPERLY;
			return SUCCESS;
		 //break;
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     appl_status_flag = ERR_TIMER_RUN_PROC;
	         Error_or_Warning_Proc("14.13.13", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
		 //break;
         default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.13.14", ERROR_OCCURED, appl_status_flag);
	       	Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}	
  }
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Wait_Till_Door_Start_Open_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.14 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Door_Start_Open_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.14.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
    ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.14.02", ERROR_OCCURED, appl_status_flag);
		 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;	      
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.14.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS;
	}
	proc_bit_field |= (1 << 0);
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.14.07", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	}  
	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DETECT_DOOR_OPEN)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.14.08", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			#ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - req door open but closed \r");
		    #endif
			cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_OPEN_BUT_CLOSED;
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
            return SUCCESS;			
		//break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.14.09", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:	
             proc_bit_field |= (1 << 1);				
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
		    #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - Doors not aligned properly \r");
	        #endif
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			cur_elevator_ptr->elevator_status = ERR_DOORS_NOT_ALIGNED_PROPERLY;
			return SUCCESS;
		 //break;
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		    appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.14.10", ERROR_OCCURED, appl_status_flag);
			Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
		 //break;
         default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.14.11", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;  
	}
	 ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	 {	
		 case SUCCESS:	
            proc_bit_field |= (1 << 4);			 
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
            proc_bit_field |= (1 << 2);		 
		 break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		    appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.12.12", ERROR_OCCURED, appl_status_flag); 
			 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
		// break;
         default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.14.13", ERROR_OCCURED, appl_status_flag);
	       	Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS; 
	  }
	 ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	 {	
		 case SUCCESS:
		      appl_status_flag = ERR_SW_IS_ACTIVE;
	          Error_or_Warning_Proc("14.14.14", ERROR_OCCURED, appl_status_flag);
		      if(proc_bit_field & (1 << 4))
			  {
                 #ifdef TRACE_ERROR
	                Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
	                Print("ERR: Event - door open and close detect for door open\r");
	             #endif
				  
	             cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			     cur_elevator_ptr->elevator_status = ERR_DOOR_OPEN_AND_CLOSE_ACTIVE_FOR_OPEN;
			     return SUCCESS;
			  }
			  if(((proc_bit_field & (1 << 2))))
			  {
			      #ifdef TRACE_ERROR
	                Print("WAIT_TILL_DOOR_START_OPEN -> ABNORMAL_EVENT \r");
	                Print("ERR: Event - fast door opened\r");
	              #endif				   
	              cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			      cur_elevator_ptr->elevator_status = ERR_DOOR_OPEN_FAST;
			      return SUCCESS;
			  }           			   
		 //break;
		 case SW_OR_KEY_NOT_PRESSED:
            proc_bit_field |= (1 << 3);		 
		 break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.14.15", ERROR_OCCURED, appl_status_flag);
			 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
		 //break;
         default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.14.16", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;	 
	  }
      if((proc_bit_field & (1 << 0)) && (proc_bit_field & (1 << 1)) && (proc_bit_field & (1 << 2)) && (proc_bit_field & (1 << 3)))
	  {	
            if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
			{
				appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.14.17", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_OPENED_MOTOR)) != SUCCESS)
	        {
		       appl_status_flag = ERR_TIMER_RUN_PROC;
	           Error_or_Warning_Proc("14.14.18", ERROR_OCCURED, appl_status_flag);
	           Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	        }
		    #ifdef TRACE_FLOW
	          Print("WAIT_TILL_DOOR_START_OPEN -> WAIT_TILL_DOOR_OPENED \r");
			#endif
            #ifdef TRACE_REQ			
	          Print("REQ: Door open limit SW to active \r");
	        #endif
	        cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_OPENED;	
	  }	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Wait_Till_Door_Opened_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.15 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Door_Opened_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.15.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.15.02", ERROR_OCCURED, appl_status_flag);
	     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;  
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.15.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS;
	}
	proc_bit_field |= (1 << 0);
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.15.07", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	}
   	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOOR_OPENED_MOTOR)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.15.08", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			#ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - limit sw door open not detect \r");
		    #endif
			cur_elevator_ptr->elevator_status = ERR_DOOR_OPEN_NOT_DETECT;
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
            return SUCCESS;			
		//break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.15.09", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:
		    proc_bit_field |= (1 << 1);
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
		    #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - Doors not aligned properly \r");
	        #endif
			 appl_status_flag = ERR_SW_IS_INACTIVE;
	         Error_or_Warning_Proc("14.15.10", ERROR_OCCURED, appl_status_flag);
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			cur_elevator_ptr->elevator_status = ERR_DOORS_NOT_ALIGNED_PROPERLY;
			return SUCCESS;
		// break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     appl_status_flag = ERR_SW_IS_DISABLED;
	         Error_or_Warning_Proc("14.15.11", ERROR_OCCURED, appl_status_flag);
			 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
		 //break;
		  default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.15.12", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;	 
	}
	ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	   case SUCCESS:
		  #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - req door open but closed \r");
	      #endif
		   appl_status_flag = ERR_SW_IS_ACTIVE;
	       Error_or_Warning_Proc("14.15.13", ERROR_OCCURED, appl_status_flag);
	      cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		  cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_OPEN_BUT_CLOSED;
		  return SUCCESS;
	  // break;
	   case SW_OR_KEY_NOT_PRESSED:
	        proc_bit_field |= (1 << 2); 
	   break;
	   case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	   case WARN_CUR_DATA_ID_DEV_DISABLED:
	       appl_status_flag = ERR_SW_IS_DISABLED;
	       Error_or_Warning_Proc("14.15.14", ERROR_OCCURED, appl_status_flag);
		   Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	   //break;
       default:
        	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.15.15", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS; 
	}
	ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	   case SUCCESS:
	     if(proc_bit_field == 7)
		 {
		     if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		     {
			    appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.15.16", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		     }
		     if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_TIMER_STOP_PROC;
	             Error_or_Warning_Proc("14.15.17", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		     }
			 if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
		     {
		    	 appl_status_flag = ERR_TIMER_STOP_PROC;
	             Error_or_Warning_Proc("14.15.18", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		     }
			 if((ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
	         {
	             appl_status_flag = ERR_DEV_DISABLE_PROC;
	             Error_or_Warning_Proc("14.15.19", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
	         }
			 switch(cur_elevator_ptr->before_fsm_state)
			 {
				 case FSM_STARTUP:
				    if(cur_elevator_ptr->next_stop_floor != cur_elevator_ptr->cur_floor)
			        {
				         #ifdef TRACE_ERROR
				         	Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r"); 
				            Print("ERR: event - next stop floor != cur_floor\r");
				         #endif
			             cur_elevator_ptr->elevator_status = ERR_NEXT_STOP_FLOOR_NOT_STOPPED;
			             cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
                         return SUCCESS;	
			        }
				 break;   
				 case FSM_PREPARE_USER_ENTRY_AND_EXIT:	
                    if(cur_elevator_ptr->next_stop_floor != cur_elevator_ptr->cur_floor)
			        {
				         #ifdef TRACE_ERROR
				         	Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r"); 
				            Print("ERR: event - next stop floor != cur_floor\r");
				         #endif
			             cur_elevator_ptr->elevator_status = ERR_NEXT_STOP_FLOOR_NOT_STOPPED;
			             cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
                         return SUCCESS;	
			        }
                    if(((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)) == 0))
					{
			           	#ifdef TRACE_ERROR
					       Print("WAIT_TILL_DOOR_OPENED -> ABNORMAL_EVENT \r"); 
				           Print("ERR: event - next stop floor but not stop list\r");
				        #endif
				        appl_status_flag = ERR_STOP_FLOOR_NOT_LIST;
	                    Error_or_Warning_Proc("14.15.20", ERROR_OCCURED, appl_status_flag);
			            cur_elevator_ptr->elevator_status = ERR_NEXT_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
			            cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
                        return SUCCESS;	
					}
					if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)))
					{
						cur_elevator_ptr->pending_in_car_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor);
			            --cur_elevator_ptr->num_pending_floor_calls_in_car;
			           if(cur_elevator_ptr->num_pending_floor_calls_in_car == 0 && cur_elevator_ptr->pending_in_car_floor_calls_bit_field == 0)
			           {
				          cur_elevator_ptr->cur_min_floor_call_in_car = FLOOR_ID_INVALID;
	                      cur_elevator_ptr->cur_max_floor_call_in_car = FLOOR_ID_INVALID;
			           }
					}
					if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)))
	                {
						  cur_elevator_ptr->pending_hall_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor);
				         --cur_elevator_ptr->num_pending_floor_calls_hall;
				         if(cur_elevator_ptr->num_pending_floor_calls_hall == 0 && cur_elevator_ptr->pending_hall_floor_calls_bit_field == 0)
			             {
				            cur_elevator_ptr->cur_min_floor_call_hall = FLOOR_ID_INVALID;
	                        cur_elevator_ptr->cur_max_floor_call_hall = FLOOR_ID_INVALID;
			             }
	                }
                    cur_elevator_ptr->pending_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor); 
					--cur_elevator_ptr->num_pending_floor_calls;
			        if(cur_elevator_ptr->num_pending_floor_calls == 0 && cur_elevator_ptr->pending_floor_calls_bit_field == 0)
			        {
				        cur_elevator_ptr->cur_min_floor_call = FLOOR_ID_INVALID;
	                    cur_elevator_ptr->cur_max_floor_call = FLOOR_ID_INVALID;
			        }
                    #ifdef TRACE_INFO
			           uint32_temp_disp_data =  cur_elevator_ptr->cur_floor;
			           Print("TRA: serviced floor call: %u\r", uint32_temp_disp_data);		              			           
		            #endif
                  break;					
			 }
			 #ifdef TRACE_FLOW
			     Print("WAIT_TILL_DOOR_OPENED -> PREPARE_USER_ENTRY_AND_EXIT \r");
			 #endif 
			 cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_USER_ENTRY_AND_EXIT;
		 }		 
	   break;
	   case SW_OR_KEY_NOT_PRESSED:	               
	   break;
	   case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	   case WARN_CUR_DATA_ID_DEV_DISABLED:
	       appl_status_flag = ERR_SW_IS_DISABLED;
	       Error_or_Warning_Proc("14.15.21", ERROR_OCCURED, appl_status_flag);
		   Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
//	   break;
       default:
        	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.15.22", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	}	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Prepare_User_Entry_And_Exit_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.16

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Prepare_User_Entry_And_Exit_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t cur_floor, min_floor, max_floor, oper;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.16.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("PREPARE_USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.16.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	if((ret_status = Check_Stationary_Door_Opened_State(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		appl_status_flag = ERR_CHECK_STATIONARY;
	    Error_or_Warning_Proc("14.16.03", ERROR_OCCURED, appl_status_flag);
	    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
		#ifdef TRACE_ERROR 
	         Print("PREPARE_USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");
		     Print("ERR: Event - stationary door opened state invalid \r");
	    #endif
	    return SUCCESS;
	}
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.16.04", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("PREPARE_USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
    }
		if((ret_status = SW_Oper(USER_BLOCKS_DOOR_SENSOR_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		{
			 appl_status_flag = ERR_DEV_ENABLE_PROC;
	         Error_or_Warning_Proc("14.16.05", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
		}
		if((ret_status = SW_Oper(MANUAL_DOOR_CTRL_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		{
			 appl_status_flag = ERR_DEV_ENABLE_PROC;
	         Error_or_Warning_Proc("14.16.06", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
		}
		if(cur_elevator_ptr->before_fsm_state == FSM_STARTUP)
		{
			if((ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		    {
		    	 appl_status_flag = ERR_DEV_ENABLE_PROC;
	             Error_or_Warning_Proc("14.16.08", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		    }
			for(oper = 1; oper < 3; ++oper)
			{
				switch(oper)
				{
					case 1:
					   if(cur_elevator_ptr->cur_floor == FLOOR_00)
					   {
						     min_floor = FLOOR_01;
					         max_floor = TOP_MOST_FLOOR_ID;
							 ++oper;
					   }
					   else
					   {
						   if(cur_elevator_ptr->cur_floor == TOP_MOST_FLOOR_ID)
						   {
							    min_floor = FLOOR_00;
					            max_floor = TOP_MOST_FLOOR_ID - 1; 
								++oper;
						   }
						   else
						   {
							   min_floor = FLOOR_00;
					           max_floor = cur_elevator_ptr->cur_floor - 1; 
						   }
					   }
                    break;
                    case 2:
                        min_floor = cur_elevator_ptr->cur_floor + 1;
                        max_floor = TOP_MOST_FLOOR_ID;
				    break;		
				}
				for(cur_floor = min_floor; cur_floor <= max_floor; ++cur_floor)
			    {
			     	if((ret_status = SW_Oper(hall_call_arr[cur_floor], DEV_ENABLE_OPER)) != SUCCESS)
	                {
	                    appl_status_flag = ERR_DEV_ENABLE_PROC;
	                    Error_or_Warning_Proc("14.16.09", ERROR_OCCURED, appl_status_flag);
	                    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                return SUCCESS;
	                }
		            if((ret_status = SW_Oper(in_car_call_arr[cur_floor], DEV_ENABLE_OPER)) != SUCCESS)
	                {
	                	appl_status_flag = ERR_DEV_ENABLE_PROC;
						#ifdef TRACE_ERROR
						  uint32_temp_disp_data = in_car_call_arr[cur_floor];
						  Print("ERR: IN CAR CALL IO CH : %u, ",uint32_temp_disp_data);
						  uint32_temp_disp_data = cur_floor;
						  Print("cur floor : %u \r", uint32_temp_disp_data);
						#endif  
	                    Error_or_Warning_Proc("14.16.10", ERROR_OCCURED, appl_status_flag);
	                    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                return SUCCESS;
	                }
				}
			}
		}		
		if((ret_status = SW_Oper(hall_call_arr[cur_elevator_ptr->cur_floor], DEV_DISABLE_OPER)) != SUCCESS)
	    {
	       appl_status_flag = ERR_DEV_DISABLE_PROC;
	       Error_or_Warning_Proc("14.16.11", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	    }
		if((ret_status = SW_Oper(in_car_call_arr[cur_elevator_ptr->cur_floor], DEV_DISABLE_OPER)) != SUCCESS)
	    {
	     	appl_status_flag = ERR_DEV_DISABLE_PROC;
	        Error_or_Warning_Proc("14.16.12", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	    }
		#ifdef TRACE_FLOW
		   Print("PREPARE_USER_ENTRY_AND_EXIT -> USER_ENTRY_AND_EXIT \r");
		#endif
        cur_elevator_ptr->before_fsm_state = FSM_PREPARE_USER_ENTRY_AND_EXIT;
		cur_elevator_ptr->cur_fsm_state = FSM_USER_ENTRY_AND_EXIT;
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_User_Entry_And_Exit_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.17

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_User_Entry_And_Exit_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	static uint8_t loop_flag = 0;
	uint8_t proc_bit_field = 0, elevator_status = 0;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		loop_flag = 0;
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.17.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
		   loop_flag = 0;
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
		  loop_flag = 0;
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.17.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Door_Opened_State(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		loop_flag = 0;
		 appl_status_flag = ERR_CHECK_STATIONARY;
	     Error_or_Warning_Proc("14.17.03", ERROR_OCCURED, appl_status_flag);
	     cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		  #ifdef TRACE_ERROR
		     Print("USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");			
		     Print("ERR: Event - stationary door opened state invalid \r");
	    #endif
	    return SUCCESS;
	}
	   if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	   {
		   loop_flag = 0;
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.17.04", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	          Print("USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	   }
        proc_bit_field = 0;
		ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_READ_OPER);
	    switch(ret_status)
	    {
	        case SUCCESS:
	            if((loop_flag & (1 << 1)) == 0)
				{
                   #ifdef TRACE_INFO
				      Print("WARN: event - car overloaded \r");
				   #endif
                   #ifdef TRACE_REQ				   
					  Print("REQ: Car to be not overload \r");
                   #endif
				   loop_flag |= (1 << 1);
				   loop_flag &= ~(1 << 2);
				   return SUCCESS;
				}
				else
				{
					return SUCCESS;
				}
	        //break;
	        case SW_OR_KEY_NOT_PRESSED:	
                 proc_bit_field |= (1 << 2);
                 loop_flag &= ~(1 << 1);
				 if((loop_flag & (1 << 2)) == 0)
				 {
                    #ifdef TRACE_FLOW
				      Print("TRA: Car is not overloaded \r");
                    #endif	
                   	 loop_flag |= (1 << 2);
				 }					
	        break;
	        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	        case WARN_CUR_DATA_ID_DEV_DISABLED:
			    loop_flag = 0;
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.17.05", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        //break;
            default:
			   loop_flag = 0;
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.17.06", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	    }
		if(proc_bit_field & (1 << 2))
		{
			if((ret_status = Compute_Floor_Stop_Datas(ctrl_elevator_ch_id, DOOR_OPENED_STAGE, &elevator_status)) != SUCCESS)
	        {
				    loop_flag = 0;
	                appl_status_flag = ERR_NEXT_STOP_FLOOR_PROC;
    	            Error_or_Warning_Proc("14.17.07", ERROR_OCCURED, appl_status_flag);   
		            cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
		            cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		            return SUCCESS;
	        }	
            switch(elevator_status)
	        {
                 case NO_PENDING_FLOOR_CALLS:
	             case STARTUP_STATIONARY:
                      return SUCCESS;      		  
	             // break;
				 default: 
				     loop_flag = 0;
                   	 #ifdef TRACE_DATA 
				     Print("TRA: After Compute Floor Data - Opened stage \r");
					 Print("=============================================\r");
					 uint32_temp_disp_data = cur_elevator_ptr->cur_fsm_state;
                     Print("cur fsm                       : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data =  cur_elevator_ptr->cur_floor;      
	                 Print("cur_floor                     : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data =  cur_elevator_ptr->next_stop_floor; 
	                 Print("next_stop_floor               : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data =  cur_elevator_ptr->cur_min_floor_call; 
	                 Print("min_stop_floor                : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data =  cur_elevator_ptr->cur_max_floor_call; 
	                 Print("max_stop_floor                : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data = cur_elevator_ptr->elevator_status; 
	                 Print("status                        : %u\r", uint32_temp_disp_data);
					 uint32_temp_disp_data = cur_elevator_ptr->pending_floor_calls_bit_field;
	                 Print("pending floor calls           : 0x%x\r", uint32_temp_disp_data);
					 Print("=============================================\r");                    
                   #endif
	        }
			if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_OPENED)) != SUCCESS)
			{
				      loop_flag = 0;
					  appl_status_flag = ERR_TIMER_RUN_PROC;
	                  Error_or_Warning_Proc("14.17.08", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
			}
			if((ret_status = SW_Oper(MANUAL_DOOR_CLOSE_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
		    {
				      loop_flag = 0;
			          appl_status_flag = ERR_DEV_ENABLE_PROC;
	                  Error_or_Warning_Proc("14.17.09", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
		    }
    	    #ifdef TRACE_FLOW
	           Print("USER_ENTRY_AND_EXIT -> PREPARE_FOR_DOOR_CLOSE \r");
			#endif
            #ifdef TRACE_REQ			
               Print("REQ: Wait till Timeout for close\r");			   
	       #endif
			cur_elevator_ptr->cur_fsm_state = FSM_PREPARE_FOR_DOOR_CLOSE;
		}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Prepare_Door_Close_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.18

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Prepare_Door_Close_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	static uint8_t loop_flag = 0;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		loop_flag = 0; 
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.18.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   loop_flag = 0; 
		   #ifdef TRACE_INFO
	          Print("PREPARE_FOR_DOOR_CLOSE -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
		  loop_flag = 0; 
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.18.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Door_Opened_State(ctrl_elevator_ch_id, cur_elevator_ptr->cur_fsm_state)) != SUCCESS)
	{
		loop_flag = 0;
		 appl_status_flag = ERR_CHECK_STATIONARY;
	     Error_or_Warning_Proc("14.18.03", ERROR_OCCURED, appl_status_flag);
		 #ifdef TRACE_ERROR 
	         Print("PREPARE_FOR_DOOR_CLOSE -> ABNORMAL_EVENT \r");
		     Print("ERR: Event - stationary door opened state invalid \r");
	    #endif
	     cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
	     return SUCCESS;
	}
	   if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	   {
		   loop_flag = 0; 
		     appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	         Error_or_Warning_Proc("14.18.04", ERROR_OCCURED, appl_status_flag);
	        #ifdef TRACE_ERROR 
	          Print("PREPARE_FOR_DOOR_CLOSE -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	   }
     ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	{
	      case SUCCESS:
	           if((loop_flag & (1 << 1)) == 0)
				{
                   #ifdef TRACE_INFO
				      Print("WARN: event - car overloaded \r");
				   #endif
                   #ifdef TRACE_REQ				   
					  Print("REQ: Car to be not overload \r");
                   #endif
				   loop_flag |= (1 << 1);
				   loop_flag &= ~(1 << 2);
				   if((ret_status = Timer_Pause(CH_ID_01)) != SUCCESS)
				   {
					   appl_status_flag = ERR_TIMER_PAUSE_PROC;
	                   Error_or_Warning_Proc("14.18.05", ERROR_OCCURED, appl_status_flag);
	                   Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
				   }
				   return SUCCESS;
				}
				else
				{
					return SUCCESS;
				}
	        //break;
	        case SW_OR_KEY_NOT_PRESSED:	
                 proc_bit_field |= (1 << 1);
                 loop_flag &= ~(1 << 1);
				 if((loop_flag & (1 << 2)) == 0)
				 {
                    #ifdef TRACE_FLOW
				      Print("TRA: Car is not overloaded \r");
                    #endif	
                   	 loop_flag |= (1 << 2);
					 if((ret_status = Timer_Pause(CH_ID_01)) != SUCCESS)
				     {
						 loop_flag = 0; 
					     appl_status_flag = ERR_TIMER_PAUSE_PROC;
	                     Error_or_Warning_Proc("14.18.06", ERROR_OCCURED, appl_status_flag);
	                     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
						 return SUCCESS;
				     }
					 if((ret_status = Timer_Resume(CH_ID_01, TIMER_ID_DOOR_OPENED)) != SUCCESS)
					 {
						 loop_flag = 0; 
						appl_status_flag = ERR_TIMER_RESUME_PROC;
	                    Error_or_Warning_Proc("14.18.07", ERROR_OCCURED, appl_status_flag);
	                    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		                return SUCCESS; 
					 }
				 }					
	        break;
	        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	        case WARN_CUR_DATA_ID_DEV_DISABLED:
			    loop_flag = 0; 
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.18.08", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        //break;
            default:
			    loop_flag = 0; 
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.18.09", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	    }
    ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
		    loop_flag = 0; 
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOOR_OPENED)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.18.10", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			#ifdef TRACE_FLOW
		      Print("PREPARE_FOR_DOOR_CLOSE -> TRIGGER_DOOR_CLOSE \r");			 
		    #endif		
	        cur_elevator_ptr->cur_fsm_state = FSM_TRIGGER_DOOR_CLOSE; 
            return SUCCESS;			
		//break;
		default:
		  loop_flag = 0; 
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.18.11", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	ret_status = SW_Oper(MANUAL_DOOR_CTRL_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	    case SUCCESS:
		   proc_bit_field |= (1 << 0);
           break;
	    case SW_OR_KEY_NOT_PRESSED:               				
	    break;
	    case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	    case WARN_CUR_DATA_ID_DEV_DISABLED:
		   loop_flag = 0; 
		   appl_status_flag = ERR_SW_IS_DISABLED;
	       Error_or_Warning_Proc("14.18.12", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	    //break;
        default:
		    loop_flag = 0;
          appl_status_flag = ERR_SW_READ_PROC;
	      Error_or_Warning_Proc("14.18.13", ERROR_OCCURED, appl_status_flag);
	     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((proc_bit_field & (1 << 0)) && (proc_bit_field & (1 << 1)))
	{
	   ret_status = SW_Oper(MANUAL_DOOR_CLOSE_SW_IO_CH, DEV_READ_OPER);
	   switch(ret_status)
	   {
	      case SUCCESS:
		     loop_flag = 0;   
             if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		     {
				 loop_flag = 0; 
			    appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.18.14", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	         }
		     #ifdef TRACE_INFO
			    Print("TRA: Triggered Manual Door Close \r");
			 #endif
             #ifdef TRACE_FLOW			 
		        Print("PREPARE_FOR_DOOR_CLOSE -> TRIGGER_DOOR_CLOSE \r");			 
		     #endif		
	         cur_elevator_ptr->cur_fsm_state = FSM_TRIGGER_DOOR_CLOSE; 
			 return SUCCESS;
      	  //break;
	      case SW_OR_KEY_NOT_PRESSED:               				
	      break;
	      case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	      case WARN_CUR_DATA_ID_DEV_DISABLED:
		     loop_flag = 0; 
		     appl_status_flag = ERR_SW_IS_DISABLED;
	         Error_or_Warning_Proc("14.18.15", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;
	    //break;	     
          default:
		      loop_flag = 0;  
              appl_status_flag = ERR_SW_READ_PROC;
	          Error_or_Warning_Proc("14.18.16", ERROR_OCCURED, appl_status_flag);
	          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		      return SUCCESS;
	   }
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Trigger_Door_Close_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.19

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Trigger_Door_Close_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	static uint8_t loop_flag = 0;
	uint8_t proc_bit_field = 0;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		loop_flag = 0;
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.19.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("TRIGGER_DOOR_CLOSE -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
		   loop_flag = 0;
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
		  loop_flag = 0;
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.19.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	{
	      case SUCCESS:
	           if((loop_flag & (1 << 1)) == 0)
				{
                   #ifdef TRACE_INFO
				      Print("WARN: event - car overloaded \r");
				   #endif
                   #ifdef TRACE_REQ				   
					  Print("REQ: Car to be not overload \r");
                   #endif
				   loop_flag |= (1 << 1);
				   loop_flag &= ~(1 << 2);
				   return SUCCESS;
				}
				else
				{
					return SUCCESS;
				}
	        //break;
	        case SW_OR_KEY_NOT_PRESSED:	
                 proc_bit_field |= (1 << 1);
                 loop_flag &= ~(1 << 1);
				 if((loop_flag & (1 << 2)) == 0)
				 {
                    #ifdef TRACE_FLOW
				      Print("TRA: Car is not overloaded \r");
                    #endif	
                   	 loop_flag |= (1 << 2);
				 }					
	        break;
	        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	        case WARN_CUR_DATA_ID_DEV_DISABLED:
			    loop_flag = 0;
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.19.03", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        //break;
            default:
			     loop_flag = 0;
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.19.04", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	    }
	if((proc_bit_field & (1 << 1)))
	{
		loop_flag = 0;
	   if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
	   {
		  	appl_status_flag = ERR_IO_CH_WRITE;
	        Error_or_Warning_Proc("14.19.05", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	   }
	   if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_HIGH)) != SUCCESS)
	   {
		    appl_status_flag = ERR_IO_CH_WRITE;
	       Error_or_Warning_Proc("14.19.06", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	   }
	   if((ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_ENABLE_OPER)) != SUCCESS)
	   {		   
	    	appl_status_flag = ERR_DEV_ENABLE_PROC;
	        Error_or_Warning_Proc("14.19.07", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	   }
	   if((ret_status = SW_Oper(MANUAL_DOOR_CLOSE_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
	   {
		   	 appl_status_flag = ERR_DEV_DISABLE_PROC;
	         Error_or_Warning_Proc("14.19.08", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	   }
	   if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DETECT_DOOR_CLOSE)) != SUCCESS)
	   {
		   	appl_status_flag = ERR_TIMER_RUN_PROC;
	        Error_or_Warning_Proc("14.19.09", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	   }
	   #ifdef TRACE_FLOW
	      Print("TRIGGER_DOOR_CLOSE -> WAIT_TILL_DOOR_START_CLOSE \r");
	   #endif
       #ifdef TRACE_REQ	  
	      Print("REQ: Door open limit SW to inactive \r");
	   #endif
	   cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_START_CLOSE;
	}	   
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Wait_Till_Door_Start_Close_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.20 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Door_Start_Close_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	static uint8_t loop_flag = 0;
  
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		loop_flag = 0;
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.20.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
    ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
		   loop_flag = 0;
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
		  loop_flag = 0;
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.20.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.20.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS; 
	}
	proc_bit_field |= (1 << 0);
	ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:	
             proc_bit_field |= (1 << 1);				
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
		    #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - Doors not aligned properly \r");
	        #endif
			loop_flag = 0; 
			appl_status_flag = ERR_SW_IS_INACTIVE;
	        Error_or_Warning_Proc("14.20.07", ERROR_OCCURED, appl_status_flag);
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			cur_elevator_ptr->elevator_status = ERR_DOORS_NOT_ALIGNED_PROPERLY;
			return SUCCESS;
		 //break;
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:		    
		     loop_flag = 0;
			 appl_status_flag = ERR_SW_IS_DISABLED;
	         Error_or_Warning_Proc("14.20.08", ERROR_OCCURED, appl_status_flag);
			 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	
		 //break;
         default:
		    loop_flag = 0;
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.20.09", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	 
	}
	 ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	 {	
		 case SUCCESS:	
            proc_bit_field |= (1 << 4);			 
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
            proc_bit_field |= (1 << 2);		 
		 break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     loop_flag = 0;
		     appl_status_flag = ERR_SW_IS_DISABLED;
	         Error_or_Warning_Proc("14.20.10", ERROR_OCCURED, appl_status_flag);
			 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;	
		// break;
         default:
		    loop_flag = 0;
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.20.11", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	 
	  }
	 ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	 {	
		 case SUCCESS:
		      appl_status_flag = ERR_SW_IS_ACTIVE;
	          Error_or_Warning_Proc("14.20.12", ERROR_OCCURED, appl_status_flag);
		      if(proc_bit_field & (1 << 4))
			  {
                 #ifdef TRACE_ERROR
	                Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
	                Print("ERR: Event - door open and close active for close\r");
	             #endif
	             cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			     cur_elevator_ptr->elevator_status = ERR_DOOR_OPEN_AND_CLOSE_ACTIVE_FOR_CLOSE;
			     return SUCCESS;
			  }
              if(proc_bit_field & (1 << 2))
			  {
			      #ifdef TRACE_ERROR
	                Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
	                Print("ERR: Event - fast door close \r");
	              #endif
	              cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			      cur_elevator_ptr->elevator_status = ERR_DOOR_CLOSE_FAST;
			      return SUCCESS;
			  }   
		 //break;
		 case SW_OR_KEY_NOT_PRESSED:
            proc_bit_field |= (1 << 3);		 
		 break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     loop_flag = 0;
		     appl_status_flag = ERR_SW_IS_DISABLED;
	          Error_or_Warning_Proc("14.20.13", ERROR_OCCURED, appl_status_flag);
			  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS; 
		 //break;
         default:
		    loop_flag = 0;
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.20.14", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS; 
	  }
	  ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_READ_OPER);
	 switch(ret_status)
	{
	      case SUCCESS:
                   #ifdef TRACE_INFO
				      Print("WARN: event - car overloaded \r");
				   #endif
                   #ifdef TRACE_REQ	  
					  Print("REQ: Car to be not overload \r");
                   #endif
				   loop_flag &= ~(1 << 2);
				   if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		           {
		              appl_status_flag = ERR_TIMER_STOP_PROC;
	                  Error_or_Warning_Proc("14.20.15", ERROR_OCCURED, appl_status_flag);
	                  Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		              return SUCCESS;
		           }
		           if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
	               {
	                 appl_status_flag = ERR_IO_CH_WRITE;
	                 Error_or_Warning_Proc("14.20.16", ERROR_OCCURED, appl_status_flag);
	                 Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		             return SUCCESS;
	             }
	             if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
	             {
	             	appl_status_flag = ERR_IO_CH_WRITE;
	                Error_or_Warning_Proc("14.20.17", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;
	             }
		         if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_CLOSE_TO_START_OPEN)) != SUCCESS)
	             {
	             	appl_status_flag = ERR_TIMER_RUN_PROC;
	                Error_or_Warning_Proc("14.20.18", ERROR_OCCURED, appl_status_flag);
					Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
	                return appl_status_flag;
	             }
		         #ifdef TRACE_FLOW
				    Print("WAIT_TILL_DOOR_START_CLOSE -> WAIT_FOR_DOOR_CLOSE_TO_START_OPEN \r");
				 #endif
                #ifdef TRACE_REQ		
				    Print("REQ: Wait for motor from door close to open \r");
                #endif	
                cur_elevator_ptr->cur_fsm_state = FSM_WAIT_FOR_DOOR_CLOSE_TO_START_OPEN;
			    return SUCCESS;
	        break;
	        case SW_OR_KEY_NOT_PRESSED:	
                 proc_bit_field |= (1 << 5);
                 loop_flag &= ~(1 << 1);
				 if((loop_flag & (1 << 2)) == 0)
				 {
                    #ifdef TRACE_FLOW
				      Print("TRA: Car is not overloaded \r");
                    #endif	
                   	 loop_flag |= (1 << 2);
				 }					
	        break;
	        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	        case WARN_CUR_DATA_ID_DEV_DISABLED:
			    loop_flag = 0;
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.20.19", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        //break;
            default:
			    loop_flag = 0;
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.20.20", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	    }
	   if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	   {
		    loop_flag = 0;
		    appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	        Error_or_Warning_Proc("14.20.21", ERROR_OCCURED, appl_status_flag);
            #ifdef TRACE_ERROR 
	          Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
		      Print("ERR: event - poll hall and in car call \r");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	   }
	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
		     loop_flag = 0;
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DETECT_DOOR_CLOSE)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.20.22", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			#ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOOR_START_CLOSE -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - req door close but opened \r");
		    #endif
			cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_CLOSE_BUT_OPENED;
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
            return SUCCESS;			
		//break;
		default:
		   loop_flag = 0;
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.20.23", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
      if((proc_bit_field & (1 << 0)) && (proc_bit_field & (1 << 1)) && (proc_bit_field & (1 << 2)) && (proc_bit_field & (1 << 3)) && (proc_bit_field & (1 << 5)))
	  {	
           loop_flag = 0;
            if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
			{
				appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.20.24", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
	        if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_CLOSED_MOTOR)) != SUCCESS)
	        {
		       appl_status_flag = ERR_TIMER_RUN_PROC;
	           Error_or_Warning_Proc("11.20.25", ERROR_OCCURED, appl_status_flag);
	           Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	        }
		    #ifdef TRACE_FLOW
	          Print("WAIT_TILL_DOOR_START_CLOSE -> WAIT_TILL_DOOR_CLOSED \r");
			#endif
            #ifdef TRACE_REQ	  
	          Print("REQ: Door close limit SW to active \r");
	        #endif
	        cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_CLOSED;	
	  }			
	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Wait_Till_Door_Closed_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.21

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Door_Closed_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
  static uint8_t loop_flag = 0;
	uint8_t proc_bit_field = 0;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		loop_flag = 0;
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.21.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
		    loop_flag = 0;
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
		  loop_flag = 0; 
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.21.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.21.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS; 
	}
	proc_bit_field |= (1 << 0);
	 ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:
		    proc_bit_field |= (1 << 1);
		 break;
		 case SW_OR_KEY_NOT_PRESSED:
		    #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - Doors not aligned properly \r");
	        #endif
			loop_flag = 0; 
			appl_status_flag = ERR_SW_IS_INACTIVE;
	        Error_or_Warning_Proc("14.21.07", ERROR_OCCURED, appl_status_flag);
	        cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
			cur_elevator_ptr->elevator_status = ERR_DOORS_NOT_ALIGNED_PROPERLY;
			return SUCCESS;
		// break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		     loop_flag = 0;
		    appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.21.08", ERROR_OCCURED, appl_status_flag);
		    Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	
		 //break;
         default:
		    loop_flag = 0;
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.21.09", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;	 
	}
	ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	   case SUCCESS:
		  #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - req door close but opened \r");
	      #endif
		   loop_flag = 0;
		  appl_status_flag = ERR_SW_IS_ACTIVE;
	       Error_or_Warning_Proc("14.21.10", ERROR_OCCURED, appl_status_flag); 
	      cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_CLOSE_BUT_OPENED;
          return SUCCESS;
	   // break;
	   case SW_OR_KEY_NOT_PRESSED:
	        proc_bit_field |= (1 << 2); 
	   break;
	   case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	   case WARN_CUR_DATA_ID_DEV_DISABLED:	       
	       loop_flag = 0;
		   appl_status_flag = ERR_SW_IS_DISABLED;
	       Error_or_Warning_Proc("14.21.11", ERROR_OCCURED, appl_status_flag);
		   Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;	
	   //break;
       default:
	       loop_flag = 0;
        	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.21.12", ERROR_OCCURED, appl_status_flag);
	         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	}
	 if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	   {
		    loop_flag = 0;
		     appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	         Error_or_Warning_Proc("14.21.13", ERROR_OCCURED, appl_status_flag);
	         #ifdef TRACE_ERROR 
	           Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
		       Print("ERR: event - poll hall and in car call \r");
	         #endif
		     cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	         cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	   }
  
	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
		    loop_flag = 0;
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOOR_CLOSED_MOTOR)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.21.14", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}			
		    #ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOOR_CLOSED -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - door closed not detected \r");
		    #endif
			cur_elevator_ptr->elevator_status = ERR_DOOR_CLOSE_NOT_DETECT;
		    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
            return SUCCESS;			
		//break;
		default:
		   loop_flag = 0;
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.21.15", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}  
	if(proc_bit_field == 0x07)
	{
		proc_bit_field = 0;
		ret_status = SW_Oper(OVERLOAD_SENSOR_IO_CH, DEV_READ_OPER);
	    switch(ret_status)
	    {
	      case SUCCESS:
		         #ifdef TRACE_INFO
				      Print("WARN: event - car overloaded \r");
				#endif
                #ifdef TRACE_REQ		  
				      Print("REQ: Car to be not overload \r");
                 #endif
				loop_flag &= ~(1 << 2);	
				proc_bit_field |= (1 << 3);
	        break;
	        case SW_OR_KEY_NOT_PRESSED:	
                 loop_flag &= ~(1 << 1);
				 if((loop_flag & (1 << 2)) == 0)
				 {
                    #ifdef TRACE_FLOW
				      Print("TRA: Car is not overloaded \r");
                    #endif	
                   	 loop_flag |= (1 << 2);
				 }					
	        break;
	        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	        case WARN_CUR_DATA_ID_DEV_DISABLED:
			    appl_status_flag = ERR_SW_IS_DISABLED;
	            Error_or_Warning_Proc("14.21.16", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	        //break;
            default:
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.21.17", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	    }
	   	ret_status = SW_Oper(USER_BLOCKS_DOOR_SENSOR_IO_CH, DEV_READ_OPER);
	    switch(ret_status)
	    {
		       case SUCCESS:
			         proc_bit_field |= (1 << 6);  
					 #ifdef TRACE_INFO
					     Print("TRA: User blocks the closing door, so door will open \r");
					 #endif
	           break;
	           case SW_OR_KEY_NOT_PRESSED:
                  	proc_bit_field |= (1 << 7);  		   
		       break;
		       case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		       case WARN_CUR_DATA_ID_DEV_DISABLED:
			     loop_flag = 0;
		         appl_status_flag = ERR_SW_IS_DISABLED;
	             Error_or_Warning_Proc("14.21.18", ERROR_OCCURED, appl_status_flag);
			     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     //break;
              default:
			    loop_flag = 0;
            	appl_status_flag = ERR_SW_READ_PROC;
	            Error_or_Warning_Proc("14.21.19", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;	 
	    }
		if((proc_bit_field & (1 << 7)))
		{
		    ret_status = SW_Oper(MANUAL_DOOR_CTRL_SW_IO_CH, DEV_READ_OPER);
	        switch(ret_status)
	        {
		        case SUCCESS:
		    	   proc_bit_field |= (1 << 4);
	            break;
	            case SW_OR_KEY_NOT_PRESSED:             			
		        break;
		        case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		        case WARN_CUR_DATA_ID_DEV_DISABLED:
				    loop_flag = 0;
		            appl_status_flag = ERR_SW_IS_DISABLED;
	                Error_or_Warning_Proc("14.21.20", ERROR_OCCURED, appl_status_flag);
			        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;
		       //break;
               default:
			         loop_flag = 0;
                	appl_status_flag = ERR_SW_READ_PROC;
	                Error_or_Warning_Proc("14.21.21", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;	 
	        }
	        if((proc_bit_field & (1 << 4)))
		    {
			   ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_READ_OPER);
	           switch(ret_status)
	           {
		          case SUCCESS:
			         proc_bit_field |= (1 << 5);  
					 #ifdef TRACE_INFO
					     Print("TRA: Manual door open triggered\r");
					 #endif
	              break;
	              case SW_OR_KEY_NOT_PRESSED:             	  	
		          break;
		          case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		          case WARN_CUR_DATA_ID_DEV_DISABLED:
				     loop_flag = 0; 
		             appl_status_flag = ERR_SW_IS_DISABLED;
	                 Error_or_Warning_Proc("14.21.22", ERROR_OCCURED, appl_status_flag);
			         Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		             return SUCCESS;
		        //break;
                  default:
				    loop_flag = 0;
                	appl_status_flag = ERR_SW_READ_PROC;
	                Error_or_Warning_Proc("14.21.23", ERROR_OCCURED, appl_status_flag);
	                Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		            return SUCCESS;	 
	            }
			}
		}
		if(((proc_bit_field & (1 << 5))) || ((proc_bit_field & (1 << 6))) || ((proc_bit_field & (1 << 3))))
		{
			loop_flag = 0;
		   if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
		   {
		       appl_status_flag = ERR_TIMER_STOP_PROC;
	           Error_or_Warning_Proc("14.21.24", ERROR_OCCURED, appl_status_flag);
	           Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
		   }
		   if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
	       {
	        	appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.21.25", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	       }
	       if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
	       {
	        	appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.21.26", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		       return SUCCESS;
	       }
		   if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_CLOSE_TO_START_OPEN)) != SUCCESS)
	       {
	        	appl_status_flag = ERR_TIMER_RUN_PROC;
	            Error_or_Warning_Proc("14.21.27", ERROR_OCCURED, appl_status_flag);
				Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
	            return appl_status_flag;
	       }
		   #ifdef TRACE_FLOW
				 Print("WAIT_TILL_DOOR_CLOSED -> WAIT_FOR_DOOR_CLOSE_TO_START_OPEN \r");
			#endif
            #ifdef TRACE_REQ		 
				 Print("REQ: Wait for motor from door close to open \r");
           #endif	
           cur_elevator_ptr->cur_fsm_state = FSM_WAIT_FOR_DOOR_CLOSE_TO_START_OPEN;
           return SUCCESS;		   
		}
		ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_READ_OPER);
	    switch(ret_status)
	    {
	       case SUCCESS:
              loop_flag = 0;		   
			 if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
			 {
				appl_status_flag = ERR_TIMER_STOP_PROC;
	            Error_or_Warning_Proc("14.21.28", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			 }
			 if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
			 {
				appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.21.29", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
			 }
			 if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
			 {
				appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.21.30", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
			 }
			 if((ret_status = SW_Oper(MANUAL_DOOR_CTRL_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
	         {
			     appl_status_flag = ERR_DEV_DISABLE_PROC;
	             Error_or_Warning_Proc("14.21.31", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
		     }
			 if((ret_status = SW_Oper(MANUAL_DOOR_OPEN_SW_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
			 {
				 appl_status_flag = ERR_DEV_DISABLE_PROC;
	             Error_or_Warning_Proc("14.21.32", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
			 }
			 if((ret_status = SW_Oper(USER_BLOCKS_DOOR_SENSOR_IO_CH, DEV_DISABLE_OPER)) != SUCCESS)
			 {
				 appl_status_flag = ERR_DEV_DISABLE_PROC;
	             Error_or_Warning_Proc("14.21.33", ERROR_OCCURED, appl_status_flag);
	             Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		         return SUCCESS;
			 }
			 if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOORS_UNALIGNED )) != SUCCESS)
			 {
				appl_status_flag = ERR_TIMER_RUN_PROC;
	            Error_or_Warning_Proc("14.21.34", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			 }
			 #ifdef TRACE_FLOW
			      Print("WAIT_TILL_DOOR_CLOSED -> WAIT_TILL_DOORS_TO_UNALIGN \r");
			#endif
            #ifdef TRACE_REQ		  
				  Print("REQ: Doors align to inactive \r");
			 #endif
			 cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOORS_TO_UNALIGN;
			 return SUCCESS;
			 //  break;
	       case SW_OR_KEY_NOT_PRESSED:	
	       break;
	       case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	       case WARN_CUR_DATA_ID_DEV_DISABLED:
	         appl_status_flag = ERR_SW_IS_DISABLED;
	         Error_or_Warning_Proc("14.21.35", ERROR_OCCURED, appl_status_flag);
		     Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		     return SUCCESS;	
	      // break;
           default:
              appl_status_flag = ERR_SW_READ_PROC;
	          Error_or_Warning_Proc("14.21.36", ERROR_OCCURED, appl_status_flag);
	          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		      return SUCCESS;
		}
	}		
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Wait_Till_Doors_Unaligned_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.22

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_Till_Doors_Unaligned_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
	uint8_t proc_bit_field = 0;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.22.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.22.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.22.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS; 
	}
	proc_bit_field |= (1 << 0);
	ret_status = SW_Oper(DOORS_ALIGNED_SW_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
		 case SUCCESS:
		   return SUCCESS;
		 //break;
		 case SW_OR_KEY_NOT_PRESSED:
		    proc_bit_field |= (1 << 1); 
		 break;	
		 case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
		 case WARN_CUR_DATA_ID_DEV_DISABLED:
		    appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.22.07", ERROR_OCCURED, appl_status_flag);
			Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
		 //break;
         default:
          	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.22.08", ERROR_OCCURED, appl_status_flag);
	       	Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
	}
	ret_status = SW_Oper(LIMIT_SW_DOOR_OPEN_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	   case SUCCESS:
		  #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");			  
	          Print("ERR: Event - req door close but opened \r");
	      #endif
		  appl_status_flag = ERR_SW_IS_ACTIVE;
	      Error_or_Warning_Proc("14.22.09", ERROR_OCCURED, appl_status_flag);			
	      cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		  cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_CLOSE_BUT_OPENED;
          return SUCCESS;
	   // break;
	   case SW_OR_KEY_NOT_PRESSED:
	        proc_bit_field |= (1 << 2); 
	   break;
	   case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	   case WARN_CUR_DATA_ID_DEV_DISABLED:
	        appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.22.10", ERROR_OCCURED, appl_status_flag);
			Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	  // break;
       default:
        	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.22.11", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	}
	ret_status = SW_Oper(LIMIT_SW_DOOR_CLOSE_IO_CH, DEV_READ_OPER);
	switch(ret_status)
	{
	   case SUCCESS:
	     proc_bit_field |= (1 << 3); 
	   break;
	   case SW_OR_KEY_NOT_PRESSED:  	   
          #ifdef TRACE_ERROR
	          Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - req door closed but not closed \r");
	      #endif
		  appl_status_flag = ERR_SW_IS_INACTIVE;
	      Error_or_Warning_Proc("14.22.12", ERROR_OCCURED, appl_status_flag);	 
	      cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		  cur_elevator_ptr->elevator_status = ERR_REQ_DOOR_CLOSED_BUT_NOT_CLOSED;
          return SUCCESS;
	   //break;
	   case WARN_CUR_DATA_ID_DEV_NO_ACCESS:
	   case WARN_CUR_DATA_ID_DEV_DISABLED:
	        appl_status_flag = ERR_SW_IS_DISABLED;
	        Error_or_Warning_Proc("14.22.13", ERROR_OCCURED, appl_status_flag);
			Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;
	   //break;
       default:
        	appl_status_flag = ERR_SW_READ_PROC;
	        Error_or_Warning_Proc("14.22.14", ERROR_OCCURED, appl_status_flag);
	        Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	}
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.22.15", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	           Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");
		       Print("ERR: event - poll hall and in car call \r");
	         #endif
		     cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	         cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	}
	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOORS_UNALIGNED)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.22.16", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}			
		    #ifdef TRACE_ERROR
		      Print("WAIT_TILL_DOORS_TO_UNALIGN -> ABNORMAL_EVENT \r");
			  Print("ERR: Event - req doors unalign but aligned \r");
		    #endif
			cur_elevator_ptr->elevator_status = ERR_REQ_DOORS_UNALIGN_BUT_ALIGN;
		    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT; 
            return SUCCESS;			
		//break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.22.17", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
	}
	
	if((proc_bit_field & (1 << 0)) && (proc_bit_field & (1 << 1)) && (proc_bit_field & (1 << 2)) && (proc_bit_field & (1 << 3)))
	{
	    if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
	    {
			appl_status_flag = ERR_TIMER_STOP_PROC;
	        Error_or_Warning_Proc("14.22.18", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
		}
		switch(cur_elevator_ptr->before_fsm_state) 
		{
			case FSM_STARTUP:
			   #ifdef TRACE_FLOW
			      Print("WAIT_TILL_DOORS_TO_UNALIGN -> DECIDE_CAR_MOVEMENT \r");
               #endif	
               cur_elevator_ptr->cur_fsm_state = FSM_DECIDE_CAR_MOVEMENT;	   
            break;
			case FSM_PREPARE_USER_ENTRY_AND_EXIT:
			   #ifdef TRACE_FLOW
			      Print("WAIT_TILL_DOORS_TO_UNALIGN -> COMPUTE_NEXT_STOP_FLOOR \r");
               #endif	
               cur_elevator_ptr->cur_fsm_state = FSM_COMPUTE_NEXT_STOP_FLOOR;	
			break;
			default:
			   appl_status_flag = ERR_FORMAT_INVALID;
	           Error_or_Warning_Proc("14.22.19", ERROR_OCCURED, appl_status_flag);
	          Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
		}
	}			
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Compute_Next_Stop_Floor_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.23

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Compute_Next_Stop_Floor_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t elevator_status = 0;
		
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.23.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.23.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Compute_Floor_Stop_Datas(ctrl_elevator_ch_id, DOOR_CLOSED_STAGE, &elevator_status)) != SUCCESS)
	{
		 appl_status_flag = ERR_COMPUTE_STOP_FLOOR_DATAS;
	     Error_or_Warning_Proc("14.23.03", ERROR_OCCURED, appl_status_flag);
		 cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
		 cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		 return SUCCESS;
	}
	switch(elevator_status)
	{
		case NO_PENDING_FLOOR_CALLS:
		   #ifdef TRACE_ERROR
	          Print("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \r");
	          Print("ERR: Event - no pending floor call\r");
	       #endif
		    appl_status_flag = ERR_NO_PENDING_CALL_DOOR_CLOSED;
	        Error_or_Warning_Proc("14.23.04", ERROR_OCCURED, appl_status_flag);
		   cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
           return SUCCESS;		   
		//break;
		case ONE_PENDING_FLOOR_CALL:
		  //one pending floor calls
        case STARTUP_STATIONARY:
           //startup stationary		
        case TRIGGER_MOVE_UP_NO_DIR_CHANGE:						
		    //trigger car to move up		
		case TRIGGER_MOVE_UP_DIR_CHANGE:
		  //trigger car to move up
		case TRIGGER_MOVE_DOWN_NO_DIR_CHANGE:						
		   //trigger car to move down		  
		case TRIGGER_MOVE_DOWN_DIR_CHANGE:
		   //trigger car to move down
		   #ifdef TRACE_DATA 
			   Print("TRA: After Compute Floor Data - Closed stage \r");
			   Print("===========================================\r");
			   uint32_temp_disp_data = cur_elevator_ptr->cur_fsm_state;
               Print("cur fsm                       : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data =  cur_elevator_ptr->cur_floor;      
	           Print("cur_floor                     : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data =  cur_elevator_ptr->next_stop_floor; 
	           Print("next_stop_floor               : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data =  cur_elevator_ptr->cur_min_floor_call; 
	           Print("min_stop_floor                : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data =  cur_elevator_ptr->cur_max_floor_call; 
	           Print("max_stop_floor                : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data = cur_elevator_ptr->elevator_status; 
	           Print("status                        : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data = cur_elevator_ptr->pending_floor_calls_bit_field;
	           Print("pending floor calls           : 0x%x\r", uint32_temp_disp_data);
			   Print("===========================================\r");
			#elseif defined TRACE_INFO
			   Print("TRA: After Compute Floor Data - Closed stage \r");
			   Print("===========================================\r");
			   uint32_temp_disp_data =  cur_elevator_ptr->cur_floor;  
			   Print("cur_floor                     : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data =  cur_elevator_ptr->next_stop_floor; 
	           Print("next_stop_floor               : %u\r", uint32_temp_disp_data);
			   uint32_temp_disp_data = cur_elevator_ptr->pending_floor_calls_bit_field;
	           Print("pending floor calls           : 0x%x\r", uint32_temp_disp_data);
            #endif
            #ifdef TRACE_FLOW			
               Print("COMPUTE_NEXT_STOP_FLOOR -> DECIDE_CAR_MOVEMENT \r");
            #endif	   
          	cur_elevator_ptr->cur_fsm_state = FSM_DECIDE_CAR_MOVEMENT;	   
		break;  
        default:	
            appl_status_flag = ERR_FORMAT_INVALID;
		    Error_or_Warning_Proc("14.23.05", ERROR_OCCURED, appl_status_flag);
		   	Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		    return SUCCESS;				   
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Wait_For_Door_Close_To_Start_Open_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.24

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Wait_For_Door_Close_To_Start_Open_Proc(const uint8_t ctrl_elevator_ch_id)
{
    elevator_ctrl_and_status_t *cur_elevator_ptr;
	timer_or_counter_data_t retrieved_timer_or_counter_interrupt_data;
	uint16_t ret_status;
		
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.24.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	ret_status = Ext_Interrupt_Retrieve_Data_Arr(EMER_CAR_STOP_EXT_INTP_CH_ID);	
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case SUCCESS:
		   #ifdef TRACE_INFO
	          Print("WAIT_FOR_DOOR_CLOSE_TO_START_OPEN -> ABNORMAL_EVENT \r");
	          Print("Event: Emergency stop\r");
	       #endif
	       cur_elevator_ptr->elevator_status = TRIGGERED_EMERGENCY_STOP;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;  
		//break;
		default:
          appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("14.24.02", ERROR_OCCURED, appl_status_flag);
	      Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		  return SUCCESS;
	}
	if((ret_status = Check_Stationary_Limit_SW_Floor(ctrl_elevator_ch_id)) != SUCCESS)
	{
		cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		appl_status_flag = ERR_LIMIT_SW_FLOOR_FAIL_AT_STATIONARY;
		Error_or_Warning_Proc("14.24.03", ERROR_OCCURED, appl_status_flag);
		#ifdef TRACE_ERROR		  
		    Print("WAIT_FOR_DOOR_CLOSE_TO_START_OPEN -> ABNORMAL_EVENT \r");
			Print("ERR: Event - limit sw floor stationary invalid \r");
		#endif
		return SUCCESS; 
	}
	if((ret_status = Poll_Hall_And_In_Car_Floor_Calls_Proc(ctrl_elevator_ch_id)) != SUCCESS)
	{
		   appl_status_flag = ERR_POLL_FLOOR_CALLS_PROC;
	       Error_or_Warning_Proc("14.24.03", ERROR_OCCURED, appl_status_flag);
	       #ifdef TRACE_ERROR 
	           Print("WAIT_FOR_DOOR_CLOSE_TO_START_OPEN -> ABNORMAL_EVENT \r");
		       Print("ERR: event - poll hall and in car call \r");
	         #endif
		     cur_elevator_ptr->elevator_status = ERR_POLL_HALL_AND_IN_CAR_PROC;
	         cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		   return SUCCESS;
	}
	ret_status = Timer_Interrupt_Retrieve_Data_Arr(CH_ID_01, &retrieved_timer_or_counter_interrupt_data);
	switch(ret_status)
	{
		case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
		break;
		case TMR_NO_MAX_NUM_TIMEOUT_PROC:
		case TMR_BEFORE_LAST_TIMEOUT_PROC:
		case TMR_AT_LAST_TIMEOUT_PROC:
		break;
		case TMR_MAX_NUM_TIMEOUT_PROC:
            if(retrieved_timer_or_counter_interrupt_data.timer_or_counter_run_id != TIMER_ID_DOOR_CLOSE_TO_START_OPEN)
			{
				appl_status_flag = ERR_TMR_ID_INVALID;
	            Error_or_Warning_Proc("14.24.04", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS;
			}
			 if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
			 {
				appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.24.05", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
			 }
			 if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_HIGH)) != SUCCESS)
			 {
				appl_status_flag = ERR_IO_CH_WRITE;
	            Error_or_Warning_Proc("14.24.05", ERROR_OCCURED, appl_status_flag);
	            Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		        return SUCCESS; 
			 }
			 if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_DOOR_OPENED_MOTOR)) != SUCCESS)
	         {
		           appl_status_flag = ERR_TIMER_RUN_PROC;
	               Error_or_Warning_Proc("14.24.06", ERROR_OCCURED, appl_status_flag);
	               Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		           return SUCCESS;
	         }           
		     #ifdef TRACE_FLOW
		       Print("WAIT_FOR_DOOR_CLOSE_TO_START_OPEN -> WAIT_TILL_DOOR_OPENED \r");
			 #endif
             #ifdef TRACE_REQ 			 
               Print("REQ: Door open limit SW to active \r");			  
		     #endif	
             cur_elevator_ptr->before_fsm_state = FSM_WAIT_FOR_DOOR_CLOSE_TO_START_OPEN;				
		     cur_elevator_ptr->cur_fsm_state = FSM_WAIT_TILL_DOOR_OPENED; 
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("14.24.07", ERROR_OCCURED, appl_status_flag);
	       Internal_Error_Elevator_Proc(ctrl_elevator_ch_id);
		   return SUCCESS;
	}
	return SUCCESS;
}


/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Abnormal_Event_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.25

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Abnormal_Event_Proc(const uint8_t ctrl_elevator_ch_id)
{
    elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	 
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.25.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
	if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
	{
		appl_status_flag = ERR_TIMER_STOP_PROC;
	    Error_or_Warning_Proc("14.25.02", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if((ret_status = IO_Channel_Write(ALARM_LED_IO_CH, STATE_HIGH)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.25.03", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if((ret_status = IO_Channel_Write(CAR_DOOR_OPEN_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.25.04", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if((ret_status = IO_Channel_Write(CAR_DOOR_CLOSE_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.25.05", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if((ret_status = IO_Channel_Write(CAR_UP_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.25.06", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if((ret_status = IO_Channel_Write(CAR_DOWN_IO_CH, STATE_LOW)) != SUCCESS)
	{
		appl_status_flag = ERR_IO_CH_WRITE;
	    Error_or_Warning_Proc("14.25.07", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}	
	#ifdef TRACE_FLOW 
	  Print("ABNORMAL_EVENT -> IDLE \r");	  
	#endif
	cur_elevator_ptr->before_fsm_state = FSM_ABNORMAL_EVENT;
	cur_elevator_ptr->cur_fsm_state = FSM_IDLE;	
	return SUCCESS;
}


/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
