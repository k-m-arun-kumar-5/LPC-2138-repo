/**************************************************************************
   FILE          :    lcd.h
 
   PURPOSE       :    LCD Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :  
 
  CHANGE LOGS    :
	   
 **************************************************************************/
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _LCD_H
#define _LCD_H

/* ---------------------- macro defination ------------------------------------------------ */                           
#define INVALID_DATA               (0)
#define ALL_LINES                  (0)
#define NUM_LINE1                  (1)
#define NUM_LINE2                  (2)
#define NUM_LINE3                  (3)
#define NUM_LINE4                  (4)

#define NUM_COL1                   (1)

#define CHECK_BUSY_FLAG             (1)
#define NO_CHECK_BUSY_FLAG          (0)

#define DATA_INTERFACE_8_BITS       (1) 
#define DATA_INTERFACE_4_BITS       (0)

#define CHAR_FONT_5_10_DOTS        (1)
#define CHAR_FONT_5_8_DOTS         (0)

#define MAX_DISP_NUM_LINES_ALL    (1)
#define MAX_DISP_NUM_LINES_1      (0) 

/*for 20 * 4 LCD disp */ 
/* num cols = num of chars in a line */
#define MAX_AVAIL_NUM_COLS                    (20)
#define MAX_AVAIL_NUM_LINES                   (4)
                            
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
// (0x94)
#define BEGIN_LOC_LINE3                     (BEGIN_LOC_LINE1 + MAX_AVAIL_NUM_COLS) 
//(0xD4) 
#define BEGIN_LOC_LINE4                     (BEGIN_LOC_LINE2  + MAX_AVAIL_NUM_COLS) 
// (0x93)
#define END_LOC_LINE1                       (BEGIN_LOC_LINE1 + MAX_AVAIL_NUM_COLS - 1)
//(0xD3)
#define END_LOC_LINE2                       (BEGIN_LOC_LINE2  + MAX_AVAIL_NUM_COLS - 1)
//(0xA7)
#define END_LOC_LINE3                       (BEGIN_LOC_LINE3  + MAX_AVAIL_NUM_COLS - 1) 
//(0xE7)
#define END_LOC_LINE4                       (BEGIN_LOC_LINE4 + MAX_AVAIL_NUM_COLS - 1)

/* ---------------------- data type defination -------------------------------------------- */
typedef struct
 {
	uint8_t base_io_ch_ctrl;      // IO CH for RS
	uint8_t base_io_ch_data;      // IO CH for D0 for 8 bit interface or IO CH for D4 for 4 bit interface
	uint8_t access_flag        : 1;
    uint8_t enable_flag        : 1; 	
	uint8_t interface          : 1;
	uint8_t font               : 1;
    uint8_t check_bf           : 1;
	uint8_t max_avail_lines    : 2;   
	uint8_t                    : 1;  
    uint8_t max_config_lines   : 2;
	uint8_t max_avail_cols     : 5;	
	uint8_t                    : 1;
	uint8_t max_config_cols    : 5;
	uint8_t                    : 3;	
} lcd_ctrl_t;

typedef struct
{
	uint8_t lcd_cur_disp_loc;
	uint8_t lcd_cur_input_loc;
} lcd_status_t;

typedef struct
{
	uint8_t line     : 3;
    uint8_t col      : 5;	
} lcd_point_t;
 	
/* -------------------- public variable declaration --------------------------------------- */
extern lcd_ctrl_t lcd_ctrl[NUM_OUTPUT_DEV_ID_LCD_CHS]; 
extern lcd_status_t lcd_status[NUM_OUTPUT_DEV_ID_LCD_CHS];

/* -------------------- public prototype declaration --------------------------------------- */
uint8_t LCD_Init(const uint8_t lcd_ch_id);
uint8_t LCD_Clear_Screen(const uint8_t lcd_ch_id);
uint8_t Write_LCD_Command_NO_BF(const uint8_t lcd_ch_id, const uint8_t lcd_cmd);
uint8_t Write_LCD_Command(const uint8_t lcd_ch_id, const uint8_t lcd_cmd);
uint8_t Write_LCD_Data(const uint8_t lcd_ch_id, const char lcd_data);
uint8_t LCD_Disp_Str(const uint8_t lcd_ch_id, const char *const lcd_disp_str);
uint8_t Goto_XY_LCD_Disp(const uint8_t lcd_ch_id, const uint8_t start_line_num, const uint8_t start_col_num);
uint8_t Goto_XY_LCD_Input(const uint8_t lcd_ch_id, const uint8_t start_line_num, const uint8_t start_col_num);
uint8_t From_XY_To_Loc_LCD(const uint8_t lcd_ch_id, const lcd_point_t *const start_lcd_point, uint8_t *const lcd_loc);
uint8_t From_Loc_to_XY_LCD(const uint8_t lcd_ch_id, const uint8_t loc_lcd, lcd_point_t *const lcd_point_ptr);
void Set_Cur_Loc_LCD(const uint8_t lcd_ch_id, const char set_input_loc_flag,const uint8_t set_input_loc, const char set_disp_loc_flag, const uint8_t set_disp_loc);
uint8_t LCD_Write(const uint8_t lcd_ch_id, const void *const lcd_rcv_disp_num_ptr);
uint8_t LCD_Disable(const uint8_t lcd_ch_id);
uint8_t LCD_Enable(const uint8_t lcd_ch_id);
uint8_t Disable_All_LCDs(void);
uint8_t LCD_Allow_Access(const uint8_t lcd_ch_id);
uint8_t LCD_No_Access(const uint8_t lcd_ch_id);
uint8_t LCD_DeInit(const uint8_t lcd_ch_id);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
