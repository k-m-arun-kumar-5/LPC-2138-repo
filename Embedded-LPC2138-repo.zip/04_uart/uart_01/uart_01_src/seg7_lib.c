/* ********************************************************************
FILE                   : seg7_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 06 

*****************************************************************************/

#include "main.h"

#ifdef SEG7_MOD_ENABLE

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */

/* ----------------------------- const function pointer defination -------------- */


/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Write

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.01 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Seg7_Write(const uint8_t seg7_ch_id, const void *const seg7_rcv_disp_num_ptr)
{
    uint32_t seg7_num, base_power_val;	
	data_value_ptr_with_type_t *seg7_data_write_ptr;
	consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	char *seg7_str_ptr;
	uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, port_pin, ret_status = SUCCESS, base;
    uint8_t place_digit[MAX_SEG7_DIGITS], i, place_val;    
	
    if(seg7_rcv_disp_num_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	{
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	}	
	
	cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;  
    
	if(  cur_seg7_ctrl_ptr->access_flag != STATE_YES) 
	   {  
          error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
          return  error_flag;
	   }
		 
	   if( cur_seg7_ctrl_ptr->enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
          return  error_flag;
	   }
     
     seg7_data_write_ptr  = (data_value_ptr_with_type_t *)seg7_rcv_disp_num_ptr;
	 switch(seg7_data_write_ptr->data_type)
	 {
		case DATA_TYPE_IN_STR:
		  seg7_str_ptr = seg7_data_write_ptr->data_value_ptr->data_str;
		break;
		case DATA_TYPE_IN_CHAR:
		  seg7_str_ptr = seg7_data_write_ptr->data_value_ptr->data_str + seg7_data_write_ptr->data_value_ptr->data_str_len_or_pos;
		break;
		case DATA_TYPE_IN_BINARY:	
      		base = 2;
			seg7_num = seg7_data_write_ptr->data_value_ptr->data_num.val_uint_32[0];
        break;			
		case DATA_TYPE_IN_HEXA:
		    base = 16;
			seg7_num = seg7_data_write_ptr->data_value_ptr->data_num.val_uint_32[0];
		case DATA_TYPE_IN_DECIMAL:
		   base = 10;
		   seg7_num = seg7_data_write_ptr->data_value_ptr->data_num.val_uint_32[0];		   
		break;  
		case DATA_TYPE_IN_APPL_DEFINED:
		break;
		default:
		   error_flag = ERR_DATA_TYPE_INVALID;
		   return error_flag;
	}
	switch(seg7_data_write_ptr->data_type)
	{
	   case DATA_TYPE_IN_DECIMAL:
	      if(cur_seg7_ctrl_ptr->num_digits <= 0 || cur_seg7_ctrl_ptr->num_digits > MAX_SEG7_DIGITS)
		  {
		      error_flag = ERR_INVALID_FORMAT;
              return error_flag;
		  }		
	      base_power_val =  Power_Of(base, cur_seg7_ctrl_ptr->num_digits);
		  for(place_val = cur_seg7_ctrl_ptr->num_digits; place_val >= 1; --place_val)
		  {
		     seg7_num %= base_power_val;
		     base_power_val /= base; 
		     place_digit[place_val - 1] = seg7_num /base_power_val;
		     for(i = 0; i < place_val  - 1; ++i)
		     {
			    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + i,  STATE_LOW)) != SUCCESS)
		        {						 
			       error_flag = ERR_SEG7_NO_WRITE;
			       return error_flag;  
		       } 
		     }			  
		     if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + i,  STATE_HIGH)) != SUCCESS)
		     {						 
			     error_flag = ERR_SEG7_NO_WRITE;
			     return error_flag;  
		     } 
		     port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		     consucc_bit_data.start_bit_pos = port_pin;
             consucc_bit_data.bits_len = 8;	
             if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
             {       
		        consucc_bit_data.write_or_config_consucc_val = cc_digit[place_digit[place_val - 1]];
             }
             else
             {
                 consucc_bit_data.write_or_config_consucc_val = ~cc_digit[place_digit[place_val - 1]] & 0xFF; ;
             }
		     if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		     {
			    error_flag = ERR_SEG7_NO_WRITE;
			    return error_flag;
		     }			 
             SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);	
		
		    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + i,  STATE_LOW)) != SUCCESS)
		    {						 
			   error_flag = ERR_SEG7_NO_WRITE;
			   return error_flag;  
		    }
		 } 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_HIGH)) != SUCCESS)
		{						 
			   error_flag = ERR_SEG7_NO_WRITE;
			   return error_flag;  
		}
	  break;	
	}    	
  return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Disable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.02  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_Disable(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
   cur_seg7_ctrl_ptr->enable_flag = STATE_NO;
	 
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Enable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.03  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_Enable(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
   cur_seg7_ctrl_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_Seg7s

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.04  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_Seg7s(void)
{
	 uint8_t seg7_ch_id =0;
	
	 for(seg7_ch_id = 0; seg7_ch_id < NUM_OUTPUT_DEV_ID_SEG7_CHS; ++seg7_ch_id)
	 {
		   Seg7_Disable(seg7_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.05 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_Allow_Access(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
    cur_seg7_ctrl_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.06 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_No_Access(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
     cur_seg7_ctrl_ptr->access_flag = STATE_NO;
     Seg7_Disable(seg7_ch_id);
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.07 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_Init(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	 io_config_t seg7_config;
	 
	 uint8_t ret_status = SUCCESS ;	
	 
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;
	 
	 seg7_config.io_ch = cur_seg7_ctrl_ptr->io_ch_a_led;
	 seg7_config.signal = PIN_SIG_DIGITAL;
	 seg7_config.func = IO_FUNC_GPIO;
	 seg7_config.dir = IO_DIR_OUTPUT;
	 if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)
	 {
		 seg7_config.state = STATE_LOW;
	 }
	 else
	 {
		  seg7_config.state = STATE_HIGH;
	 }
	 seg7_config.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 seg7_config.port_pin_len = 8;
		 
	 if((ret_status = IO_Channels_Func_Set(&seg7_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 seg7_config.io_ch = cur_seg7_ctrl_ptr->io_ch_unit_digit;
	 seg7_config.port_pin_len = cur_seg7_ctrl_ptr->num_digits; 
	 seg7_config.state = STATE_LOW;
	 if((ret_status = IO_Channels_Func_Set(&seg7_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 return ret_status; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_DeInit

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.08 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_DeInit(const uint8_t seg7_ch_id)
{
	 io_config_t seg7_unconfig;
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS;
	 
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 Seg7_No_Access(seg7_ch_id);
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ; 
	 seg7_unconfig.io_ch  = cur_seg7_ctrl_ptr->io_ch_a_led;	 
	 seg7_unconfig.port_pin_len = 8;
	 seg7_unconfig.func = IO_FUNC_GPIO;
	 seg7_unconfig.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 if((ret_status = IO_Ch_Func_Reset(&seg7_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }	 
	 seg7_unconfig.io_ch  = cur_seg7_ctrl_ptr->io_ch_unit_digit;
	 seg7_unconfig.port_pin_len = cur_seg7_ctrl_ptr->num_digits;
	 if((ret_status = IO_Ch_Func_Reset(&seg7_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }
	 return SUCCESS;
}
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
