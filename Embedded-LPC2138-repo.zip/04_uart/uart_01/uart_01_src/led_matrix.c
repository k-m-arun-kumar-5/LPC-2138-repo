/**************************************************************************
   FILE          :    led_matrix.c
 
   PURPOSE       :     
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 05  
	   
 **************************************************************************/
 
 #include "main.h"
 
 #ifdef LED_MATRIX_MOD_ENABLE
 
/* ------------------------------ macro defination ------------------------------ */
    

/* ----------------------------- global variable defination --------------------- */
 // for 5 * 7 led DOT matrix, row_scan, type common row cathode define row values for each of the five columns corresponding to number 0 to 9
      const uint8_t led_dot_disp_map[(MAX_LED_MATRIX_NUM_CHARS + 2)* NUM_DISP_MAP_EACH_CHAR ] =
	  {
		                               0x1F, 0x11, 0x11, 0x1F, 0x10, 0x10, 0x1F, 0x00, //9 
		                               0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E, 0x00, //0
		                               0x04, 0x06, 0x04, 0x04, 0x04, 0x04, 0x0E, 0x00, //1
									   0x0E, 0x11, 0x10, 0x08, 0x04, 0x02, 0x1F, 0x00, //2
									   0x1F, 0x10, 0x10, 0x1C, 0x10, 0x10, 0x1F, 0x00, //3
									   0x11, 0x11, 0x11, 0x1F, 0x10, 0x10, 0x10, 0x00, //4 
									   0x1F, 0x01, 0x01, 0x1F, 0x10, 0x10, 0x1F, 0x00, //5
									   0x1F, 0x01, 0x01, 0x1F, 0x11, 0x11, 0x1F, 0x00, //6 
									   0x1F, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x00, //7
									   0x1F, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x1F, 0x00, //8
									   0x1F, 0x11, 0x11, 0x1F, 0x10, 0x10, 0x1F, 0x00, //9
                                       0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E, 0x00  //0
      };
static consucc_bit_t port_write;    
static uint32_t repeat;		  
static int32_t cur_disp_map_index = NUM_DISP_MAP_EACH_CHAR;	  
static uint8_t num_scan_row_or_col, io_ch_scan_base, io_ch_port_write, mask_data = 0;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t Disp_Char_To_Disp_Map_Index(const char disp_char, uint8_t *const map_index_ptr);
static uint8_t Disp_Refresh(const uint8_t led_matrix_ch_id);

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_Write

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :               

Func ID        : 05.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t LED_Matrix_Write(const uint8_t led_matrix_ch_id, const void *const led_matrix_char_ptr)
{
	 data_value_ptr_with_type_t *led_matrix_data_write_ptr;
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	 output_data_ctrl_para_t *led_matrix_ctrl_ptr;
	 consucc_bit_t port_write_scan;	 
     char *led_matrix_str_ptr;    
	 uint8_t ret_status = SUCCESS, base, port_pin, led_matrix_char_code, min_cur_char_disp_map, max_cur_char_disp_map ;
	   
	if(led_matrix_char_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}		 
    if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	{
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	}	 
	cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;
	if( cur_led_matrix_ctrl_ptr->access_flag != STATE_YES) 
	{  
          error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
          return  error_flag;
	}		 
	if( cur_led_matrix_ctrl_ptr->enable_flag != STATE_YES) 
	{  
         error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
         return  error_flag;
	}	  
	led_matrix_data_write_ptr  = (data_value_ptr_with_type_t *)led_matrix_char_ptr;	
	switch(led_matrix_data_write_ptr->data_type)
	{
		case DATA_TYPE_IN_STR:
		  led_matrix_str_ptr = led_matrix_data_write_ptr->data_value_ptr->data_str;
		break;
		case DATA_TYPE_IN_CHAR:
		  led_matrix_str_ptr = led_matrix_data_write_ptr->data_value_ptr->data_str + led_matrix_data_write_ptr->data_value_ptr->data_str_len_or_pos;
		  Disp_Char_To_Disp_Map_Index(*led_matrix_str_ptr, &led_matrix_char_code);		  
		break;
		case DATA_TYPE_IN_BINARY:	
      		base = 2;
			led_matrix_char_code = led_matrix_data_write_ptr->data_value_ptr->data_num.val_int_8[0];
        break;			
		case DATA_TYPE_IN_HEXA:
		    base = 16;
			led_matrix_char_code = led_matrix_data_write_ptr->data_value_ptr->data_num.val_int_8[0];
		case DATA_TYPE_IN_DECIMAL:
		   base = 10;
		   led_matrix_char_code = led_matrix_data_write_ptr->data_value_ptr->data_num.val_int_8[0];		   
		break;  
		case DATA_TYPE_IN_APPL_DEFINED:
		break;
		default:
		   error_flag = ERR_DATA_TYPE_INVALID;
		   return error_flag;
	}
	switch(led_matrix_data_write_ptr->data_type)
	{
		case DATA_TYPE_IN_CHAR:
		case DATA_TYPE_IN_HEXA:
		case DATA_TYPE_IN_DECIMAL:
	      if(cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN)
	      {
		     io_ch_port_write = cur_led_matrix_ctrl_ptr->io_ch_rowa;		  
		     io_ch_scan_base = cur_led_matrix_ctrl_ptr->io_ch_col1;		
	         if(cur_led_matrix_ctrl_ptr->font_size == FONT_SIZE_5_7)
		     {
	            port_write.bits_len = 7;
		        num_scan_row_or_col = 5;			   
		    }
            else
		    {
	           port_write.bits_len = 8;
		       num_scan_row_or_col = 8;
		    }
	     }
	     else
	     {
	    	io_ch_port_write = cur_led_matrix_ctrl_ptr->io_ch_col1;
	    	io_ch_scan_base = cur_led_matrix_ctrl_ptr->io_ch_rowa;		
	        if(cur_led_matrix_ctrl_ptr->font_size == FONT_SIZE_5_7)
		    {
	           port_write.bits_len = 5;
		       num_scan_row_or_col = 7;
		    }
            else
		    {
	           port_write.bits_len = 8;
		       num_scan_row_or_col = 8;
		    }	
	    }
	
	    port_write_scan.start_bit_pos = io_ch_scan_base % NUM_PINS_PER_PORT;
	    port_write_scan.bits_len = num_scan_row_or_col;
        if((cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_CATHODE_TYPE) ||
          (cur_led_matrix_ctrl_ptr->scan_type == ROW_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_ANODE_TYPE))	
	    {
	        mask_data = 0;
	        for(repeat = 0; repeat < port_write.bits_len; ++repeat)
	        {
	         	mask_data |= 1 << repeat;
	        }
	    }
	    port_write_scan.write_or_config_consucc_val = 0;
	    if((cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_ANODE_TYPE) || 
          (cur_led_matrix_ctrl_ptr->scan_type == ROW_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_CATHODE_TYPE))
	    {
	        for(repeat = 0; repeat < num_scan_row_or_col; ++repeat)
	        {
	           port_write_scan.write_or_config_consucc_val |=  1 << repeat;  
	        }
	    }
	    if((ret_status = Port_Write(io_ch_scan_base, &port_write_scan))!= SUCCESS)
	    {
		    error_flag = ERR_LED_MATRIX_WRITE;
	  	    return error_flag;
	    }
        port_pin = io_ch_port_write % NUM_PINS_PER_PORT;
	    port_write.start_bit_pos = port_pin;
	    led_matrix_ctrl_ptr = (output_data_ctrl_para_t *)led_matrix_data_write_ptr->data_ctrl_para_ptr;
	    switch(led_matrix_ctrl_ptr->led_matrix_scroll_fmt)
	    {
		    case DISP_LED_DOT_MATRIX_INC:
		       min_cur_char_disp_map = (led_matrix_char_code - 1)* (num_scan_row_or_col + 1);
		       max_cur_char_disp_map = min_cur_char_disp_map + (num_scan_row_or_col + 1);
		       for(cur_disp_map_index = min_cur_char_disp_map; cur_disp_map_index < max_cur_char_disp_map; ++cur_disp_map_index)
		       {
			      if((ret_status = Disp_Refresh(led_matrix_ch_id)) != SUCCESS)
			      {
				     error_flag = ERR_LED_MATRIX_WRITE;
			         return error_flag;
			      }
		      }			   
		    break;
		    case DISP_LED_DOT_MATRIX_DCR:
		       min_cur_char_disp_map = led_matrix_char_code * (num_scan_row_or_col + 1);	
		       max_cur_char_disp_map = min_cur_char_disp_map + (num_scan_row_or_col + 1);
		       for(cur_disp_map_index = max_cur_char_disp_map; cur_disp_map_index > min_cur_char_disp_map; --cur_disp_map_index)
		       {
                  if((ret_status = Disp_Refresh(led_matrix_ch_id)) != SUCCESS)
			      {
				     error_flag = ERR_LED_MATRIX_WRITE;
			         return error_flag;
			     }			   
		      }
		    break;
		    case DISP_LED_DOT_MATRIX_NO_CHANGE:
		       if((ret_status = Disp_Refresh(led_matrix_ch_id)) != SUCCESS)
		       {
				  error_flag = ERR_LED_MATRIX_WRITE;
			       return error_flag;
		       }
		    break;		  
		    default:
               error_flag = ERR_INVALID_FORMAT;
		       return error_flag;
	    }
	    break;
	}	
	return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Disp_Refresh

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :               

Func ID        : 05.02  

BUGS           :     
-*------------------------------------------------------------*/
static uint8_t Disp_Refresh(const uint8_t led_matrix_ch_id)
{   
    led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;	
	uint8_t scan_data, ret_status; 
	int8_t scan_row_or_col;
	
    cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;
    for(repeat = 0; repeat < REQ_REPEAT_CHAR_COUNT; ++repeat)
	{
		 for(scan_row_or_col = 0; scan_row_or_col < num_scan_row_or_col ; ++scan_row_or_col)
		 {
           if((cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_CATHODE_TYPE) || 
             (cur_led_matrix_ctrl_ptr->scan_type == ROW_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_ANODE_TYPE))
		   {
			    scan_data = STATE_HIGH;
		   }
		   else
		   {
			    scan_data = STATE_LOW;
		   }
		   
	     if((ret_status = IO_Channel_Write(io_ch_scan_base + scan_row_or_col, scan_data )) != SUCCESS)
		   {
			   error_flag = ERR_LED_MATRIX_WRITE;
			   return error_flag;
		   }
       
		 if((cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_ANODE_TYPE) ||
            (cur_led_matrix_ctrl_ptr->scan_type == ROW_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_CATHODE_TYPE))		 
        {
            port_write.write_or_config_consucc_val = led_dot_disp_map[cur_disp_map_index + scan_row_or_col]; 	 
        }          
		else
        {
		   port_write.write_or_config_consucc_val = ~led_dot_disp_map[cur_disp_map_index + scan_row_or_col] & mask_data; 
        }
		   if((ret_status = Port_Write(io_ch_port_write, &port_write)) != SUCCESS)
		   {
			    error_flag = ERR_LED_MATRIX_WRITE;
			    return error_flag;
		   }
		   
		  // Delay_MS(REQ_SCAN_DELAY_IN_MS);
		   SW_Time_Delay(MAX_ICOUNT_LED_MATRIX_SCAN_DELAY, MAX_JCOUNT_LED_MATRIX_SCAN_DELAY);
		   if((cur_led_matrix_ctrl_ptr->scan_type == COL_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_CATHODE_TYPE) || 
         (cur_led_matrix_ctrl_ptr->scan_type == ROW_SCAN && cur_led_matrix_ctrl_ptr->row_type == ROW_ANODE_TYPE))
		   {
			   scan_data = STATE_LOW;
		   }
		   else
		   {
			   scan_data = STATE_HIGH;
		   }
		   if((ret_status = IO_Channel_Write(io_ch_scan_base + scan_row_or_col, scan_data )) != SUCCESS)
		   {
		      error_flag = ERR_LED_MATRIX_WRITE;
			  return error_flag;
		   }
		}
    }
	return SUCCESS;	
 }
   	
/*------------------------------------------------------------*
FUNCTION NAME  : Disp_Char_To_Disp_Map_Index

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.03 

Bugs           :  
-*------------------------------------------------------------*/
static uint8_t Disp_Char_To_Disp_Map_Index(const char disp_char, uint8_t *const map_index_ptr)
{
	uint8_t ret_status, base_char_map_pos ;
	
	if(map_index_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	if(disp_char >= '0' && disp_char <= '9')
	{
		base_char_map_pos = 1;
		*map_index_ptr = base_char_map_pos + (disp_char - '0');
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_Disable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.04  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_Disable(const uint8_t led_matrix_ch_id)
{
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;  
     cur_led_matrix_ctrl_ptr->enable_flag = STATE_NO;
	 
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_Enable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.05  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_Enable(const uint8_t led_matrix_ch_id)
{
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;  
     cur_led_matrix_ctrl_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_LED_Matrixs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.06  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_LED_Matrixs(void)
{
	 uint8_t led_matrix_ch_id =0;
	
	 for(led_matrix_ch_id = 0; led_matrix_ch_id < NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS; ++led_matrix_ch_id)
	 {
		   LED_Matrix_Disable(led_matrix_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.07 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_Allow_Access(const uint8_t led_matrix_ch_id)
{
	led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;  
     cur_led_matrix_ctrl_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.08 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_No_Access(const uint8_t led_matrix_ch_id)
{
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;  
     cur_led_matrix_ctrl_ptr->access_flag = STATE_NO;
     LED_Matrix_Disable(led_matrix_ch_id);
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.09 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_Init(const uint8_t led_matrix_ch_id)
{
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	 io_config_t led_matrix_config;	 
	 uint8_t ret_status = SUCCESS ;	
	 
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id ;
	 
	 led_matrix_config.io_ch = cur_led_matrix_ctrl_ptr->io_ch_rowa;
	 led_matrix_config.signal = PIN_SIG_DIGITAL;
	 led_matrix_config.dir = IO_DIR_OUTPUT;
	 led_matrix_config.func = IO_FUNC_GPIO;
	 led_matrix_config.state = STATE_LOW;
	 led_matrix_config.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 if(cur_led_matrix_ctrl_ptr->font_size == FONT_SIZE_5_7)
	    led_matrix_config.port_pin_len = 7;
	 else
		led_matrix_config.port_pin_len = 8;
		 
	 if((ret_status = IO_Channels_Func_Set(&led_matrix_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 led_matrix_config.io_ch = cur_led_matrix_ctrl_ptr->io_ch_col1;
	 if(cur_led_matrix_ctrl_ptr->font_size == FONT_SIZE_5_7)
	    led_matrix_config.port_pin_len = 5;
	 else
		led_matrix_config.port_pin_len = 8;
	 led_matrix_config.state = STATE_LOW;
	 if((ret_status = IO_Channels_Func_Set(&led_matrix_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 return SUCCESS; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : LED_Matrix_DeInit

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 05.10

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LED_Matrix_DeInit(const uint8_t led_matrix_ch_id)
{
	 io_config_t led_matrix_unconfig;
	 led_matrix_ctrl_t *cur_led_matrix_ctrl_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS ;	
	 
	 if(led_matrix_ch_id >= NUM_OUTPUT_DEV_ID_LED_MATRIX_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_led_matrix_ctrl_ptr = led_matrix_ctrl + led_matrix_ch_id;
	 
	 LED_Matrix_No_Access(led_matrix_ch_id);
	 led_matrix_unconfig.io_ch  = cur_led_matrix_ctrl_ptr->io_ch_rowa;
	 if(cur_led_matrix_ctrl_ptr->font_size ==FONT_SIZE_5_7)
	    led_matrix_unconfig.port_pin_len = 7;
	 else
		led_matrix_unconfig.port_pin_len = 8; 
	 led_matrix_unconfig.func = IO_FUNC_GPIO;
	 led_matrix_unconfig.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 if((ret_status = IO_Ch_Func_Reset(&led_matrix_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }	 
	 led_matrix_unconfig.io_ch  = cur_led_matrix_ctrl_ptr->io_ch_col1;
	 if(cur_led_matrix_ctrl_ptr->font_size == FONT_SIZE_5_7)
	    led_matrix_unconfig.port_pin_len = 5;
	 else
		led_matrix_unconfig.port_pin_len = 8;  
     if((ret_status = IO_Ch_Func_Reset(&led_matrix_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }
	 return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
