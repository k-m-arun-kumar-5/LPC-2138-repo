/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  led flash ON shift it down using software delay
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 	
                       
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

#define SHIFT_REG_DATA_1       (1)
#define SHIFT_REG_DATA_0       (0)

value_types to_disp;

void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
static uint_8 System_Init(void);
static uint_8 HW_Init(void *get_init_ptr);
static void PLL_Init(void);
static void GPIO_Init(void );
static uint_8 Shift8_One_Cycle(void);
static void Shift_Reg_Send_Data(uint_8 data);
/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 000  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{	
     if(System_Init() != SUCCESS)
		 return FAILURE;
	 while(1)
	 {
		   Shift8_One_Cycle();  
	 }
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(void *get_init_ptr)
{
	PLL_Init();
	GPIO_Init();
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for crystal oscillitor of 12 MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static void PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static void GPIO_Init(void)
{
	PINSEL0 = 0x0;
	IOCLR0 = 0xFFFFFFFF;
	IODIR0 = 1 << SHIFT_REG_CLOCK | 1 << SHIFT_REG_DATA;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Shift8_One_Cycle

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 005  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 Shift8_One_Cycle(void)
{
	uint_8 i = 0;
	
	SW_Time_Delay(MAX_ICOUNT_SW_DELAY, MAX_JCOUNT_SW_DELAY);
	Shift_Reg_Send_Data(SHIFT_REG_DATA_1);
	while(i++ < NUM_LEDS - 1)
	{
		SW_Time_Delay(MAX_ICOUNT_SW_DELAY, MAX_JCOUNT_SW_DELAY);
	  Shift_Reg_Send_Data(SHIFT_REG_DATA_0);
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 006  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count)
{
	 uint_32 i, j;
	
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Shift_Reg_Send_Data

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 007  

BUGS           :              
-*------------------------------------------------------------*/
static void Shift_Reg_Send_Data(uint_8 data)
{
	  IOCLR0 = 1 << SHIFT_REG_CLOCK;
	  if(data & 0x01)
		{
			 IOSET0 = 1 << SHIFT_REG_DATA;
		}
		else
		{
			  IOCLR0 = 1 << SHIFT_REG_DATA;
		}
		IOSET0 = 1 << SHIFT_REG_CLOCK;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
