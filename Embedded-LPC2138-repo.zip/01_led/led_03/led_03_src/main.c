/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : flash led on and off alternating when any switch is pressed ie if LED1 is flashed OFF and 
                         when SW2 is pressed then LED1 is flashed ON and when SW4 is pressed, then LED1 is flashed OFF.  
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 

CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

#define LED_ON_FSM                 (0)
#define LED_OFF_FSM                (1) 

void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
static uint_8 System_Init(void);
static uint_8 HW_Init(void *get_init_ptr);
static void PLL_Init(void);
static void GPIO_Init(void );

value_types to_disp;

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

BUGS           :
-*------------------------------------------------------------*/
int main(void)
{
	void LED_Change_State(void);
	uint_8 ret_status;
	static uint_8 fsm_sw1_state = KEY_RELEASED, fsm_sw2_state = KEY_RELEASED, fsm_sw3_state = KEY_RELEASED,fsm_sw4_state = KEY_RELEASED ;
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
   
	while(1)
	{	
        if(fsm_sw1_state == KEY_RELEASED && (!(IO1PIN & 1 << SW1_PORT1_POS))) 
		{
			fsm_sw1_state = KEY_PRESSED;	
			LED_Change_State();
		}
        else
		{
			if(fsm_sw1_state == KEY_PRESSED && (IO1PIN & 1 << SW1_PORT1_POS))
			   fsm_sw1_state = KEY_RELEASED;	
		}
		if(fsm_sw2_state == KEY_RELEASED && (!(IO1PIN & 1 << SW2_PORT1_POS))) 
		{
			fsm_sw2_state = KEY_PRESSED;
            LED_Change_State();			
		}
        else
		{
			if(fsm_sw2_state == KEY_PRESSED && (IO1PIN & 1 << SW2_PORT1_POS))
			   fsm_sw2_state = KEY_RELEASED;	
		}
		if(fsm_sw3_state == KEY_RELEASED && (!(IO1PIN & 1 << SW3_PORT1_POS))) 
		{
			fsm_sw3_state = KEY_PRESSED;	
            LED_Change_State();			
		}
        else
		{
			if(fsm_sw3_state == KEY_PRESSED && (IO1PIN & 1 << SW3_PORT1_POS))
			   fsm_sw3_state = KEY_RELEASED;	
		}
		if(fsm_sw4_state == KEY_RELEASED && (!(IO1PIN & 1 << SW4_PORT1_POS))) 
		{
			fsm_sw4_state = KEY_PRESSED;
            LED_Change_State();			
		}
        else
		{
			if(fsm_sw4_state == KEY_PRESSED && (IO1PIN & 1 << SW4_PORT1_POS))
			   fsm_sw4_state = KEY_RELEASED;	
		}
			   
	}
	return FAILURE;
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(void *get_init_ptr)
{
	PLL_Init();
	GPIO_Init();
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for crystal oscillitor of 12 MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static void PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static void GPIO_Init(void)
{
	PINSEL2 = 0x0;
	PINSEL0 = 0x0;
	
	IO0DIR = 1 << LED_PORT0_POS;
	IO0CLR = 1 << LED_PORT0_POS;
	IO1DIR = 0 << SW1_PORT1_POS | 0 << SW2_PORT1_POS | 0 << SW3_PORT1_POS | 0 << SW4_PORT1_POS;		
}


/*------------------------------------------------------------*-
FUNCTION NAME  : SW_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 005 

BUGS           :
-*------------------------------------------------------------*/
void SW_Delay(uint_32 i_count, uint_32 j_count)
{
	uint_32 i, j;
	for (i = 0; i < i_count; ++i)
	{
	  for(j = 0; j < j_count; ++j);	 
	}		
	return;  
}

/*------------------------------------------------------------*-
FUNCTION NAME  : LED_Change_State

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 

Func ID        : 006  

BUGS           :
-*------------------------------------------------------------*/
void LED_Change_State(void)
{
    static uint_8 fsm_led_state = LED_OFF_FSM; 
	
    switch(fsm_led_state)
	{
			   case LED_ON_FSM:
			     IO0CLR = 1 << LED_PORT0_POS;
				 fsm_led_state = LED_OFF_FSM;
			   break;
               case LED_OFF_FSM:
 		         IO0SET = 1 << LED_PORT0_POS;
				 fsm_led_state = LED_ON_FSM;
			   break; 			     
	}        	
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
