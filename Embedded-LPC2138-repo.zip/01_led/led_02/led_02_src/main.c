/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : when SW is pressed on then LED flash on, and when SW is released then LED flash OFF
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 

CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
static uint_8 System_Init(void);
static uint_8 HW_Init(void *get_init_ptr);
static void PLL_Init(void);
static void GPIO_Init(void );

value_types to_disp;

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

BUGS           :
-*------------------------------------------------------------*/
int main(void)
{
	uint_8 ret_status;
		
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
   
	while(1)
	{	
        if(!(IO1PIN & 1 << SW_PORT1_POS))
		  IO0SET = 1 << LED_PORT0_POS;
         else
 		   IO0CLR = 1 << LED_PORT0_POS;        
	}
	return FAILURE;
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(void *get_init_ptr)
{
	PLL_Init();
	GPIO_Init();
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for crystal oscillitor of 12 MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static void PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static void GPIO_Init(void)
{
	PINSEL2 = 0x0;
	PINSEL0 = 0x0;
	
	IO0DIR = 1 << LED_PORT0_POS;
	IO0CLR = 1 << LED_PORT0_POS;
	IO1DIR = 0 << SW_PORT1_POS;	
	
}


/*------------------------------------------------------------*-
FUNCTION NAME  : SW_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 005 

BUGS           :
-*------------------------------------------------------------*/
void SW_Delay(uint_32 i_count, uint_32 j_count)
{
	uint_32 i, j;
	for (i = 0; i < i_count; ++i)
	{
	  for(j = 0; j < j_count; ++j);	 
	}		
	return;  
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
