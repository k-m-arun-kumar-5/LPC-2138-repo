/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : interlocking  of led with  reset sw.
                          At first, led is off and all keys are released. when sw2 is pressed then led is  flashed on 
						  and when sw2 is released, led is flashed off, when sw1 is pressed on then sw1 locks led and led is flashed on and 
						  when sw2 is pressed, then led remains flashed on and when sw2 is released, then led remains flashed on
						  when sw1 is released then sw1 release the locks and led is flashed off. Same situation applies to sw2, which locks led.
						  led_reset_sw is used to flash led off at whatever state of sw1 and sw2 is. 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 

CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

#define LED_ON_FSM                 (0)
#define LED_OFF_FSM                (1)	

#define SW1_FLAG                   (0)
#define SW2_FLAG                   (1)
	
value_types to_disp;
uint_8  sw1_ctrl_led_flag = STATE_YES_IN_CHAR, sw2_ctrl_led_flag = STATE_YES_IN_CHAR ;

void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
static uint_8 System_Init(void);
static uint_8 HW_Init(void *get_init_ptr);
static void PLL_Init(void);
static void GPIO_Init(void );

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 000  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint_8 ret_status;
	
	void LED_Change_State(uint_8 );
	static uint_8 fsm_sw1_state = KEY_RELEASED, fsm_sw2_state = KEY_RELEASED, fsm_reset_sw_state = KEY_RELEASED;
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
   
	while(1)
	{	
        if(fsm_reset_sw_state == KEY_RELEASED && !(IO1PIN & 1 << RESET_SW_PORT1_POS))
		{
			fsm_reset_sw_state = KEY_PRESSED;
			sw1_ctrl_led_flag = STATE_NO_IN_CHAR;
			sw2_ctrl_led_flag = STATE_NO_IN_CHAR;
			IO0CLR = 1 << LED_PORT0_POS;
		}
		else
		{
			if(fsm_reset_sw_state == KEY_PRESSED && (IO1PIN & 1 << RESET_SW_PORT1_POS))
			{
				fsm_reset_sw_state = KEY_RELEASED;
        sw1_ctrl_led_flag = STATE_YES_IN_CHAR;
			  sw2_ctrl_led_flag = STATE_YES_IN_CHAR;  				
			}				
		}
        if(fsm_sw1_state == KEY_RELEASED && (!(IO1PIN & 1 << SW1_PORT1_POS))) 
		{
			fsm_sw1_state = KEY_PRESSED;
            if(sw1_ctrl_led_flag == STATE_YES_IN_CHAR )	
			{				 
                 IO0SET = 1 << LED_PORT0_POS;
				 sw2_ctrl_led_flag = STATE_NO_IN_CHAR;
			}				 
		}
        else
		{
			if(fsm_sw1_state == KEY_PRESSED && (IO1PIN & 1 << SW1_PORT1_POS))
			{
			   fsm_sw1_state = KEY_RELEASED;
			   if(sw1_ctrl_led_flag == STATE_YES_IN_CHAR )	
			   {
			      IO0CLR = 1 << LED_PORT0_POS;
			      sw2_ctrl_led_flag = STATE_YES_IN_CHAR;
			   }
			}	   
		}
				
		if(fsm_sw2_state == KEY_RELEASED && (!(IO1PIN & 1 << SW2_PORT1_POS))) 
		{
			fsm_sw2_state = KEY_PRESSED;	
             if(sw2_ctrl_led_flag == STATE_YES_IN_CHAR)
			 {				 
                 IO0SET = 1 << LED_PORT0_POS;
				 sw1_ctrl_led_flag = STATE_NO_IN_CHAR;
			 }				 
		}
        else
		{
			if(fsm_sw2_state == KEY_PRESSED && (IO1PIN & 1 << SW2_PORT1_POS))
			{
			   fsm_sw2_state = KEY_RELEASED;
			   if(sw2_ctrl_led_flag == STATE_YES_IN_CHAR )	
			   {
			      IO0CLR = 1 << LED_PORT0_POS;
			      sw1_ctrl_led_flag = STATE_YES_IN_CHAR;
			   }
			}			   
		}	   
	}
	return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(void *get_init_ptr)
{
	PLL_Init();
	GPIO_Init();
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static void PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static void GPIO_Init(void)
{
	PINSEL2 = 0x0;
	PINSEL0 = 0x0;
	
	IO0DIR = 1 << LED_PORT0_POS;
	IO0CLR = 1 << LED_PORT0_POS;
	IO1DIR = 0 << SW1_PORT1_POS | 0 << SW2_PORT1_POS |0 << RESET_SW_PORT1_POS;		
}

/*------------------------------------------------------------*-
FUNCTION NAME  : LED_Change_State

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 005 

BUGS           :
-*------------------------------------------------------------*/
void LED_Change_State(uint_8 sw_flag)
{
    static uint_8 fsm_led_state = LED_OFF_FSM; 
	
    switch(fsm_led_state)
	{
			   case LED_ON_FSM:			     				 
                 if(sw_flag == SW1_FLAG)
				 {
					 sw2_ctrl_led_flag = STATE_YES_IN_CHAR;
				 }
                 else
				 {
					 sw1_ctrl_led_flag = STATE_YES_IN_CHAR;
				 }	
				 IO0CLR = 1 << LED_PORT0_POS;
				 fsm_led_state = LED_OFF_FSM;
			   break;
               case LED_OFF_FSM:
			     if(sw_flag == SW1_FLAG)
				 {
					 sw2_ctrl_led_flag = STATE_NO_IN_CHAR;
				 }
                 else
				 {
					 sw1_ctrl_led_flag = STATE_NO_IN_CHAR;
				 }	
 		         IO0SET = 1 << LED_PORT0_POS;
				 fsm_led_state = LED_ON_FSM;
			   break; 			     
	}        	
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
