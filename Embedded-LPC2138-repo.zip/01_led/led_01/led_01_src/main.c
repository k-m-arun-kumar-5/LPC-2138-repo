/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : flash led on and off periodically using software delay
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : next Func ID : 006 

CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
void Delay_MS(const uint_32 max_elapsed_time_in_ms );
void Delay_US(const uint_32 max_elapsed_time_in_us );
static uint_8 System_Init(void);
static uint_8 HW_Init(void *get_init_ptr);
static void PLL_Init(void);
static void GPIO_Init(void );
void Led1_Blink_One_Cycle(void);
value_types to_disp;


/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

BUGS           :
-*------------------------------------------------------------*/
int main(void)
{
	uint_8 ret_status;
	void SW_Delay(uint_32 i_count, uint_32 j_count);
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
   	
	while(1)
	{
		Led1_Blink_One_Cycle();
        IO1SET = 1 << LED2_PORT1_POS; 
		Led1_Blink_One_Cycle();
		IO1CLR = 1 << LED2_PORT1_POS;
	}
	return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(void *get_init_ptr)
{
	PLL_Init();
	GPIO_Init();
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for crystal oscillitor of 12 MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static void PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static void GPIO_Init(void)
{
	PINSEL2 = 0x0;
	//IO1CLR = 1 << LED1_PORT1_POS | 1 << LED2_PORT1_POS;
	IO1DIR = 1 << LED1_PORT1_POS | 1 << LED2_PORT1_POS;
    IO1SET = 1 << LED1_PORT1_POS | 1 << LED2_PORT1_POS;	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : SW_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 005 

BUGS           :
-*------------------------------------------------------------*/
void SW_Delay(uint_32 i_count, uint_32 j_count)
{
	uint_32 i, j;
	for (i = 0; i < i_count; ++i)
	{
	    for(j = 0; j < j_count; ++j);	 
	}		
	return;  
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Led1_Blink_One_Cycle

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 006 

BUGS           :
-*------------------------------------------------------------*/
void Led1_Blink_One_Cycle(void)
{
    // SW_Delay(I_COUNT_SW_DELAY, J_COUNT_SW_DELAY);
	  Delay_MS(REQ_LED1_STATE_DELAY_IN_MS);		
		IO1SET = 1 << LED1_PORT1_POS;
		//SW_Delay(I_COUNT_SW_DELAY, J_COUNT_SW_DELAY);
		Delay_MS(REQ_LED1_STATE_DELAY_IN_MS);
 		IO1CLR = 1 << LED1_PORT1_POS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_MS

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.11 

Bugs           :   
-*------------------------------------------------------------*/
void Delay_MS(const uint_32 max_elapsed_time_in_ms )
{
  uint_32 max_elapsed_inst_cycle = max_elapsed_time_in_ms * _XTAL_FREQ  * (1000/4), elapsed_inst_cycle;
	
	for(elapsed_inst_cycle = 0; elapsed_inst_cycle < max_elapsed_inst_cycle; ++elapsed_inst_cycle)
	{
		 __asm("NOP");
	}
}	

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_US

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.12 

Bugs           :   
-*------------------------------------------------------------*/
void Delay_US(const uint_32 max_elapsed_time_in_us )
{
   uint_32 max_elapsed_inst_cycle = max_elapsed_time_in_us * (_XTAL_FREQ / 4) , elapsed_inst_cycle;
	
	for(elapsed_inst_cycle = 0; elapsed_inst_cycle < max_elapsed_inst_cycle; ++elapsed_inst_cycle)
	{
		   __asm("NOP");
	}
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
