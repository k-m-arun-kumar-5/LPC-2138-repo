/**************************************************************************
   FILE          :    io_conf.h
 
   PURPOSE       :   main peripherial configuration Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _IO_CONF_H
 #define _IO_CONF_H
 

/* -------------------------------- OSC Freq conf -------------------------------------*/
 #define _XTAL_FREQ                              (12000000)
 
 /* --------------------------------- module enable conf ---------------------------------*/ 
//#define TIMER1_MOD_ENABLE                      (01)
 #define TIMER2_MOD_ENABLE                      (02) 
// #define TIMER0_MOD_ENABLE                      (03)
// #define LCD_MOD_ENABLE                         (04)
// #define KEYPAD_MOD_ENABLE                      (05)
// #define CAPTURE_MOD_ENABLE                     (06)
// #define COMPARE_MOD_ENABLE                     (07)
// #define PWM_MOD_ENABLE                         (08)
 #define USART_MOD_ENABLE                       (09)
// #define ADC_MOD_ENABLE                         (10)
// #define GSM_MOD_ENABLE                         (11)
// #define COMPARATOR1_MOD_ENABLE                 (12)
// #define COMPARATOR2_MOD_ENABLE                 (13)
// #define SPI_MOD_ENABLE                         (14)
// #define I2C_MOD_ENABLE                         (15) 
// #define WATCHDOG_TIMER_MOD_ENABLE              (16)

/* ------------------------------- LCD oper conf ---------------------------------------*/
 
 #define LCD_DISP_ERR_LINE_NUM            (NUM_LINE4) 
 
/* for 20 * 4 LCD disp */                             
#define BEGIN_LOC_LINE1                      (0X80)
#define BEGIN_LOC_LINE2                      (0xC0)
#define BEGIN_LOC_LINE3                      (0x94) 
#define BEGIN_LOC_LINE4                      (0xD4)
#define END_LOC_LINE1                        (0x93)
#define END_LOC_LINE2                        (0xD3)
#define END_LOC_LINE3                        (0xA7) 
#define END_LOC_LINE4                        (0xE7)

/* num cols = num of chars in a line */
#define MAX_AVAIL_NUM_COLS                    (20)
#define CONFIGURE_MAX_NUM_LINES               (4)
#define MAX_AVAIL_NUM_LINES                   (4) 
#define MAX_AVAIL_NUM_CHARS_IN_LCD        (MAX_AVAIL_NUM_COLS * MAX_AVAIL_NUM_LINES) 
#define CONFIGURE_MAX_NUM_COLS             (MAX_AVAIL_NUM_COLS)
#define CONFIGURE_MAX_NUM_CHARS_IN_LCD    (CONFIGURE_MAX_NUM_LINES * CONFIGURE_MAX_NUM_COLS ) 
#define MAX_NUM_CHARS_INPUT_DATA          (MAX_AVAIL_NUM_COLS) 

/* -------------------------------- timer oper conf ------------------------------------*/

#define TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE                    (1U)
#define TIMER1_POSTSET_TIME_DELAY_IN_MULTIPLE                   (2U) 
#define TIMER1_SET_TIME_DELAY_IN_MULTIPLE                       TIMER1_PRESET_TIME_DELAY_IN_MULTIPLE

#define TIMER1_TICK_IN_MILLI_SEC                                (50U)  
#define TIMER1_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC           TIME_UNIT_1_SEC_IN_MILLI_SEC
 //in Timer1_Load_Init_Val_Calc() in timer.c, change variable inc_timer1, which (directly loads initial TMR1 values ), depends on Osc freq
 
 
#define TIMER2_PRESET_TIME_DELAY_IN_MULTIPLE                    (1U)
#define TIMER2_POSTSET_TIME_DELAY_IN_MULTIPLE                   (2U) 
#define TIMER2_SET_TIME_DELAY_IN_MULTIPLE                       TIMER2_PRESET_TIME_DELAY_IN_MULTIPLE
 
#define TIMER2_TICK_IN_MILLI_SEC                               (50U)  
#define TIMER2_REQ_TIME_1_UPDATE_REACHED_IN_MILLI_SEC          TIME_UNIT_1_SEC_IN_MILLI_SEC 
//in Timer2_Load_Init_Val_Calc() in timer.c, change variable inc_timer2, which (directly loads initial TMR2 values ), depends on Osc freq
  
/* ------------------------------- uart oper conf -------------------------------------- */

//in UART_Init() in uart.c, change SPBRG, which dependc on Osc freq  and baud rate

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
