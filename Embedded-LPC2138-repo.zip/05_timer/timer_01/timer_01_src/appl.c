/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
 
uint16_t appl_error_or_warning_flag ;
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:		  
		break;
		default:
		   appl_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_error_or_warning_flag);
		   return appl_error_or_warning_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Appl_Proc(void)
{		
    uint16_t ret_status;
	
	switch(cur_data_id) 
	{	
        case DATA_ID_LED_BLINK:
		    UART_Transmit_Str(TRACE_UART_CH_ID, "\r Appl_proc");
            if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_HIGH )) != SUCCESS)
			{
				appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		        Error_or_Warning_Proc("11.02.01", ERROR_OCCURED, appl_error_or_warning_flag);
		        return appl_error_or_warning_flag;
			}  			
            if((ret_status = Timer_Run(CH_ID_00, TIMER_ID_LED_BLINK )) != SUCCESS)
			{
				appl_error_or_warning_flag = ERR_TIMER_RUN_PROC;
		        Error_or_Warning_Proc("11.02.02", ERROR_OCCURED, appl_error_or_warning_flag);
		        return appl_error_or_warning_flag;
			}
			if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_LOW )) != SUCCESS)
			{
				appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		        Error_or_Warning_Proc("11.02.03", ERROR_OCCURED, appl_error_or_warning_flag);
		        return appl_error_or_warning_flag;
			}  			
            if((ret_status = Timer_Run(CH_ID_00, TIMER_ID_LED_BLINK )) != SUCCESS)
			{
				appl_error_or_warning_flag = ERR_TIMER_RUN_PROC;
		        Error_or_Warning_Proc("11.02.04", ERROR_OCCURED, appl_error_or_warning_flag);
		        return appl_error_or_warning_flag;
			}	
		break;
		default:
		    appl_error_or_warning_flag = ERR_CUR_DATA_ID_INVALID;
		    Error_or_Warning_Proc("11.02.05", ERROR_OCCURED, appl_error_or_warning_flag);
		    return appl_error_or_warning_flag;
	} 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_Init(const void *const data_ptr)
{	
    uint16_t ret_status;	
	
	if((ret_status =  Next_Data_Conf_Parameter(DATA_ID_LED_BLINK)) != SUCCESS)
	{
		 appl_error_or_warning_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.04  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_HW_Init(void)
{
    uint16_t ret_status ;
	
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(INTERNAL_ERROR_LED_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(LED_BLINK_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	return SUCCESS; 
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
