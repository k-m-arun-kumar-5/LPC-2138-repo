/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
 
uint16_t appl_error_or_warning_flag = NO_ERROR ;
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_error_or_warning_flag = NO_ERROR;		
		break;
		default:
		   appl_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_error_or_warning_flag);
		   return appl_error_or_warning_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Appl_Proc(void)
{	
	timer_or_counter_data_t retrieved_timer_1_or_counter_interrupt_data;
	uint16_t ret_status, ext_intp_3_ret_status, ext_intp_2_ret_status, timer_1_intp_1_ret_status;
	uint8_t timer_run_sw_ext_intp_ch_id = CH_ID_03, timer_stop_sw_ext_intp_ch_id = CH_ID_02, run_timer_ch_id = CH_ID_01;
	static uint8_t fsm_timer_state = FSM_TIMER_STOPPED;
 	
	switch(cur_data_id) 
	{	
        case DATA_ID_LED_BLINK:	
            switch(fsm_timer_state)
		   {
		       case FSM_TIMER_RUNNING:
		           //STOP TIMER : BEGIN
		            ext_intp_2_ret_status = Ext_Interrupt_Retrieve_Data_Arr(timer_stop_sw_ext_intp_ch_id);
			        switch(ext_intp_2_ret_status)
			        {
			        	case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
                          timer_1_intp_1_ret_status = Timer_Interrupt_Retrieve_Data_Arr(run_timer_ch_id, &retrieved_timer_1_or_counter_interrupt_data);
			              switch(timer_1_intp_1_ret_status)
			              {
			             	case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
					    	break;
					    	case TMR_BEFORE_LAST_TIMEOUT_PROC:
					    	case TMR_NO_MAX_NUM_TIMEOUT_PROC:
							case TMR_AT_LAST_TIMEOUT_PROC:
				            break;
						    case TMR_MAX_NUM_TIMEOUT_PROC:
							     #ifdef TRACE
							         Print("\r TRA: Timer 1 auto stopped");
                                  #endif 	
                              
                               if((ret_status = Disable_Timer_Interrupt(run_timer_ch_id)) != SUCCESS)
				               {
				        	      appl_error_or_warning_flag = ERR_DISABLE_INTERRUPT;
		                          Error_or_Warning_Proc("11.02.01", ERROR_OCCURED, appl_error_or_warning_flag);
		                          return appl_error_or_warning_flag;
				               }
				               if((ret_status = Disable_Ext_Interrupt(timer_stop_sw_ext_intp_ch_id)) != SUCCESS)
				               {
					               appl_error_or_warning_flag = ERR_DISABLE_INTERRUPT;
		                           Error_or_Warning_Proc("11.02.02", ERROR_OCCURED, appl_error_or_warning_flag);
		                           return appl_error_or_warning_flag;
				               }
						       ret_status = Delete_Src_Interrupt_Data_Arr_By_Src(INTP_REQ_EINT2);
				               switch(ret_status)
				               {
				                    case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
				                    case SEARCH_INTP_SRC_MORE_THAN_ONE_DATA_ARR:
					                case SEARCH_INTP_SRC_ONE_DATA_ARR:
					                break;
					                default: 
					                   appl_error_or_warning_flag = ERR_DELETE_INTP_SRC_DATA_PROC;
		                               Error_or_Warning_Proc("11.02.04", ERROR_OCCURED, appl_error_or_warning_flag);
		                               return appl_error_or_warning_flag;
				               }
						       ret_status = Delete_Src_Interrupt_Data_Arr_By_Src(INTP_REQ_EINT3);
				               switch(ret_status)
				               {
				                   case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
				                   case SEARCH_INTP_SRC_MORE_THAN_ONE_DATA_ARR:
					               case SEARCH_INTP_SRC_ONE_DATA_ARR:
					               break;
					               default: 
					                 appl_error_or_warning_flag = ERR_DELETE_INTP_SRC_DATA_PROC;
		                             Error_or_Warning_Proc("11.02.05", ERROR_OCCURED, appl_error_or_warning_flag);
		                             return appl_error_or_warning_flag;
				               }
							   if((ret_status = Enable_Ext_Interrupt(timer_run_sw_ext_intp_ch_id)) != SUCCESS)
			                   {
			                 	  appl_error_or_warning_flag = ERR_ENABLE_INTERRUPT;
		                          Error_or_Warning_Proc("11.02.06", ERROR_OCCURED, appl_error_or_warning_flag);
		                          return appl_error_or_warning_flag;
		                       }
						       fsm_timer_state = FSM_TIMER_STOPPED; 
						    break;
			         	    default:
			         	       appl_error_or_warning_flag = ERR_RETRIEVE_INTP_SRC_DATA_PROC;
		                       Error_or_Warning_Proc("11.02.07", ERROR_OCCURED, appl_error_or_warning_flag);
		                       return appl_error_or_warning_flag;
			            } 
		               	break;
			         	case SUCCESS:
				          if((ret_status = Disable_Timer_Interrupt(run_timer_ch_id)) != SUCCESS)
				          {
				        	  appl_error_or_warning_flag = ERR_DISABLE_INTERRUPT;
		                      Error_or_Warning_Proc("11.02.08", ERROR_OCCURED, appl_error_or_warning_flag);
		                      return appl_error_or_warning_flag;
				          }
				          if((ret_status = Disable_Ext_Interrupt(timer_stop_sw_ext_intp_ch_id)) != SUCCESS)
				          {
					           appl_error_or_warning_flag = ERR_DISABLE_INTERRUPT;
		                       Error_or_Warning_Proc("11.02.09", ERROR_OCCURED, appl_error_or_warning_flag);
		                       return appl_error_or_warning_flag;
				          }				          
						  fsm_timer_state = FSM_TIMER_TRIGGERED_TO_STOP; 
				       break;
			           default:
				         appl_error_or_warning_flag = ERR_RETRIEVE_INTP_SRC_DATA_PROC;
		                 Error_or_Warning_Proc("11.02.10", ERROR_OCCURED, appl_error_or_warning_flag);
		                 return appl_error_or_warning_flag;
			       }
			    break;
				case FSM_TIMER_TRIGGERED_TO_STOP:
				    ret_status = Delete_Src_Interrupt_Data_Arr_By_Src(INTP_REQ_EINT3);
				    switch(ret_status)
				    {
					    case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
					    case SEARCH_INTP_SRC_MORE_THAN_ONE_DATA_ARR:
					    case SEARCH_INTP_SRC_ONE_DATA_ARR:
					    break;
					    default: 
					         appl_error_or_warning_flag = ERR_DELETE_INTP_SRC_DATA_PROC;
		                     Error_or_Warning_Proc("11.02.11", ERROR_OCCURED, appl_error_or_warning_flag);
		                     return appl_error_or_warning_flag;
				    }
					ret_status = Delete_Src_Interrupt_Data_Arr_By_Src(INTP_REQ_TMR1);
			        switch(ret_status)
			        {
			           case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
			           case SEARCH_INTP_SRC_MORE_THAN_ONE_DATA_ARR:
			           case SEARCH_INTP_SRC_ONE_DATA_ARR:
			           break;
			           default: 
			              appl_error_or_warning_flag = ERR_DELETE_INTP_SRC_DATA_PROC;
		                  Error_or_Warning_Proc("11.02.13", ERROR_OCCURED, appl_error_or_warning_flag);
		                  return appl_error_or_warning_flag;
			        }  
			        ret_status = Delete_Src_Interrupt_Data_Arr_By_Src(INTP_REQ_EINT2);
			        switch(ret_status)
			        {
			           case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
			           case SEARCH_INTP_SRC_MORE_THAN_ONE_DATA_ARR:
			           case SEARCH_INTP_SRC_ONE_DATA_ARR:
				       break;
				       default: 
				          appl_error_or_warning_flag = ERR_DELETE_INTP_SRC_DATA_PROC;
		                  Error_or_Warning_Proc("11.02.14", ERROR_OCCURED, appl_error_or_warning_flag);
		                  return appl_error_or_warning_flag;
				    }
        	         if((ret_status = Enable_Ext_Interrupt(timer_run_sw_ext_intp_ch_id)) != SUCCESS)
			         {
			         	  appl_error_or_warning_flag = ERR_ENABLE_INTERRUPT;
		                  Error_or_Warning_Proc("11.02.12", ERROR_OCCURED, appl_error_or_warning_flag);
		                  return appl_error_or_warning_flag;
		             }
			         fsm_timer_state = FSM_TIMER_STOPPED;
			break;
			case FSM_TIMER_STOPPED:
			    ext_intp_2_ret_status = Ext_Interrupt_Retrieve_Data_Arr(timer_run_sw_ext_intp_ch_id);
			    switch(ext_intp_2_ret_status)
			    {
				     case SEARCH_INTP_SRC_DATA_ARR_NOT_FOUND:
				     break;
				     case SUCCESS:
				       if((ret_status = Disable_Ext_Interrupt(timer_run_sw_ext_intp_ch_id)) != SUCCESS)
				       {
				       	  appl_error_or_warning_flag = ERR_DISABLE_INTERRUPT;
		                  Error_or_Warning_Proc("11.02.15", ERROR_OCCURED, appl_error_or_warning_flag);
		                  return appl_error_or_warning_flag;
				       }				            
				       fsm_timer_state = FSM_TIMER_TRIGGERED_TO_RUN; 
				     break;
				     default:
				         appl_error_or_warning_flag = ERR_RETRIEVE_INTP_SRC_DATA_PROC;
		                 Error_or_Warning_Proc("11.02.16", ERROR_OCCURED, appl_error_or_warning_flag);
		                 return appl_error_or_warning_flag;
		        }
			break;
		    case FSM_TIMER_TRIGGERED_TO_RUN:				        
			    if((ret_status = Enable_Ext_Interrupt(timer_stop_sw_ext_intp_ch_id)) != SUCCESS)
			    {
			       appl_error_or_warning_flag = ERR_ENABLE_INTERRUPT;
		           Error_or_Warning_Proc("11.02.17", ERROR_OCCURED, appl_error_or_warning_flag);
		           return appl_error_or_warning_flag;
			    }
			    fsm_timer_state = FSM_TIMER_RUNNING;  
			break;
			default:
			   appl_error_or_warning_flag = ERR_FORMAT_INVALID;
		       Error_or_Warning_Proc("11.02.18", ERROR_OCCURED, appl_error_or_warning_flag);
		       return appl_error_or_warning_flag;
		   }
        break;		   
		default:
		   appl_error_or_warning_flag = ERR_CUR_DATA_ID_INVALID;
		   Error_or_Warning_Proc("11.02.19", ERROR_OCCURED, appl_error_or_warning_flag);
		   return appl_error_or_warning_flag;
	 } 
     return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_Init(const void *const data_ptr)
{	
    uint16_t ret_status;	
	
	if((ret_status =  Next_Data_Conf_Parameter(DATA_ID_LED_BLINK)) != SUCCESS)
	{
		 appl_error_or_warning_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.04  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_HW_Init(void)
{
    uint16_t ret_status ;
	
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(INTERNAL_ERROR_LED_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(LED_BLINK_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	//ENABLE TIMER_RUN_SW
   if((ret_status = Enable_Ext_Interrupt(CH_ID_03)) != SUCCESS)
	{
		return FAILURE;
	}
	return SUCCESS; 
}

#ifdef TIMER_MOD_ENABLE 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_0_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.05  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_0_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_0_or_counter_data_ptr)
{
	uint16_t ret_status;
	
	if(timer_0_or_counter_data_ptr == NULL_PTR)
	{
		appl_error_or_warning_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.05.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	if(timer_0_or_counter_data_ptr->timer_or_counter_run_id != TMR_OR_COUNTER_SYSTEM_TICK_STATE)
	{
		appl_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.05.02", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	
	
	
	switch(timeout_type)
	{
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		
         default:
             appl_error_or_warning_flag = TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.05.03", ERROR_OCCURED, appl_error_or_warning_flag);
		     return appl_error_or_warning_flag;
	}
    return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Timer_1_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.06  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_1_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_1_or_counter_data_ptr)
{
   uint16_t ret_status;
   static uint8_t cur_state_blink_led = STATE_LOW;	
  
    if(timer_1_or_counter_data_ptr == NULL_PTR)
	{
		appl_error_or_warning_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.06.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	if(timer_1_or_counter_data_ptr->timer_or_counter_run_id >= NUM_TIMER_AND_COUNTER_IDS)
	{
		appl_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.06.02", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	switch(timer_1_or_counter_data_ptr->timer_or_counter_run_id)
	{
		case TIMER_ID_LED_BLINK:
     
      #ifdef TRACE
          Print("\r TRA: Timeout count: %u", timer_1_or_counter_data_ptr->elapsed_num_timeouts_or_count);
      #endif 
      switch(cur_state_blink_led)
      {
        case STATE_LOW:
           if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_HIGH)) != SUCCESS)
           {
               appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.03", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           }  
           cur_state_blink_led = STATE_HIGH;
        break;
        case STATE_HIGH:   
           if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_LOW)) != SUCCESS)
           {
              appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.04", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           }  
           cur_state_blink_led = STATE_LOW;
         break;
      }  
      /* commented due to proteus 8.3 does not toggle LED_BLINK_IO_CH, 
         but in keil uvision 5, debug session and view GPIO, it toggles LED_BLINK_IO_CH */        
          /* if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_TOGGLE)) != SUCCESS)
          {
              appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.04", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           } */
	  break;       
	 }
	 switch(timeout_type)
	 {
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		 
         default:
		     appl_error_or_warning_flag = TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.06.05", ERROR_OCCURED, appl_error_or_warning_flag);
		     return appl_error_or_warning_flag;
	 }
    return ret_status;	
}

#endif


#ifdef INTERRUPT_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_0_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.07  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_0_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_1_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.08  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_1_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_2_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.09  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_2_Proc(void)
{
	uint16_t ret_status;
	
	#ifdef TRACE
	   Print("\r TRA: Timer 1 trigger to stop");
	#endif
	
    if((ret_status = Timer_Stop(CH_ID_01)) != SUCCESS)
	{
		appl_error_or_warning_flag = ERR_TIMER_STOP_PROC;
		Error_or_Warning_Proc("11.09.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_3_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.10  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_3_Proc(void)
{
	uint16_t ret_status;
	 
	#ifdef TRACE
	   Print("\r TRA: Timer 1 trigger to run");
	#endif
	
	if((ret_status = Timer_Run(CH_ID_01, TIMER_ID_LED_BLINK )) != SUCCESS)
	{
		appl_error_or_warning_flag = ERR_TIMER_RUN_PROC;
		Error_or_Warning_Proc("11.10.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}		
	return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
