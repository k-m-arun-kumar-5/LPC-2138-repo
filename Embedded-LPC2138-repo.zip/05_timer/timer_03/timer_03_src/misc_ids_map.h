/**************************************************************************
   FILE          :    misc_ids_map.h
 
   PURPOSE       :   Data IDs, Timer IDs and general interrupt request sources configuration header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   If data terminator char = NULL_CHAR, then newly read chars are taken till max nums of chars is reached.
                 :   If data terminator char != NULL_CHAR, then if data's max data allocated char < num entered chars, then new entered chars are taken, till terminator char is read.
			            else, then newly read chars are discarded, till terminator char is read. 
  
  CHANGE LOGS    : 
	   
 **************************************************************************/
 
 #ifndef _MISC_IDS_MAP_H
 #define _MISC_IDS_MAP_H 

 //                                            DATA_ID,     NUM_CHAR, SMALL_ALPHA, BIG_ALPHA, SPECIAL_CHAR, CTRL_CHAR, I/P_STREAM,             DISP_FORMAT,               
 const data_id_ctrl_para_t data_id_ctrl_para[]  = {  
	                                         { DATA_ID_LED_BLINK, STATE_NO,  STATE_NO, STATE_NO, STATE_NO,  STATE_NO, DATA_NO_STREAM, RCVD_CHAR_DONT_DISP_FORMAT,
											 
//											  O/P_DATA_TYPE,         I/P_DATA_TYPE,     O/P_STREAM,  TX_STREAM,         RCV_STREAM,  TERMINATOR, RETRY, REQ_MAX_CHARS
											 DATA_TYPE_NO_DATA, DATA_TYPE_NO_DATA, DATA_NO_STREAM, DATA_NO_STREAM,   DATA_NO_STREAM,  NULL_CHAR,  0,       0 }                                     
										 
                                           };

//                                                 DATA_ID,          INPUT_DEV,       OUTPUT_DEV,         	RECEIVE_DEV,      TRANSMIT_DEV        									   
 const data_id_dev_src_t  data_ids_dev_srcs[] = {	                                             
                                                  { DATA_ID_LED_BLINK, {DEV_ID_INVALID}, {DEV_ID_INVALID},  {DEV_ID_INVALID}, {DEV_ID_INVALID}}
		                                       };	

#ifdef TIMER_MOD_ENABLE
//                               TIMER_ID,  TIMER_OR_COUNTER_MODE,  MATCH_OR_CAPTURE_ID, MATCH_INTERRUPT_OR_CAPTURE_RISING,    
timer_or_counter_ctrl_t timer_or_counter_ctrl[] =                                         
                             {
                              { TIMER_ID_LED_BLINK, TIMER_MODE,    CH_ID_01,               STATE_YES,
							  
//                             CAPTURE_FALLING, CAPTURE_INTERRUPT, MAX_NUM_TIMEOUTS,      TIMEOUT_IN_MS_OR_COUNT 
                                STATE_NO,       STATE_NO,          6,                          2000 }                       
							                            	
							 };
 
#endif		
				
#ifdef INTERRUPT_MOD_ENABLE
//                               VECTOR_IRQ_ISR,            INTERRUPT_REQUEST_SRC,          INTERRUPT_TYPE,      NEXT_TRIGGER_IRQS,    VECTOR_SLOT,   SAME_TRIGGER_IRQS                                     	
interrupt_request_ctrl_t  interrupt_request_ctrl[NUM_INTP_REQ_SRCS] = 
                              {
								                   {0,                                INTP_REQ_WDT,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },
																	 {0,                           INTP_REQ_RESERVED_SW_INTP,    INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },  
																	 {0,                                INTP_REQ_ARM_CORE0,      INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },
																	 {0,                                INTP_REQ_ARM_CORE1,      INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {(uint32_t)ISR_Timer_0,            INTP_REQ_TMR0,           INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },
                                                                     {(uint32_t)ISR_Timer_1,            INTP_REQ_TMR1,           INTERRUPT_REQ_VECTOR_IRQ,   STATE_NO,    VECTOR_SLOT_06,   STATE_NO },
																	 {0,                                INTP_REQ_UART0,          INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },  
																	 {0,                                INTP_REQ_UART1,          INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {0,                                INTP_REQ_PWM0,           INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {0,                                INTP_REQ_I2C0,           INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {0,                                INTP_REQ_SPI0 ,          INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },
																	 {0,                                INTP_REQ_SPI1_OR_SSP,    INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {0,                                INTP_REQ_PLL,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },   
																	 {0,                                INTP_REQ_RTC,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {(uint32_t)ISR_Ext_Interrupt_0,    INTP_REQ_EINT0,          INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {(uint32_t)ISR_Ext_Interrupt_1,    INTP_REQ_EINT1,          INTERRUPT_REQ_NA,   STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }, 
																	 {(uint32_t)ISR_Ext_Interrupt_2,    INTP_REQ_EINT2,          INTERRUPT_REQ_VECTOR_IRQ,   STATE_NO,    VECTOR_SLOT_04,   STATE_NO },  
																	 {(uint32_t)ISR_Ext_Interrupt_3,    INTP_REQ_EINT3,          INTERRUPT_REQ_VECTOR_IRQ,   STATE_NO,    VECTOR_SLOT_05,   STATE_NO },  
																	 {0,                                INTP_REQ_AD0,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },  
																	 {0,                                INTP_REQ_I2C1,           INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },  
																	 {0,                                INTP_REQ_BOD,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO },   
																	 {0,                                INTP_REQ_AD1,            INTERRUPT_REQ_NA,           STATE_NO,    VECTOR_SLOT_NA,   STATE_NO }  
							  }; 
							  
#endif	

						  
#endif
																						 
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
																						 
