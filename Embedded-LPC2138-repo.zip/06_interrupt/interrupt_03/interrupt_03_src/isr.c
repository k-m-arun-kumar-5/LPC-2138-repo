/* ********************************************************************
FILE                  : isr_vector_irq.c

PURPOSE               : interrupt service routine.  
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 13

*****************************************************************************/
#include "main.h"

#ifdef INTERRUPT_MOD_ENABLE
#include "timer.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
 uint16_t isr_vector_irq_alloc = 0; 
 
/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Init_Ext_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.01

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Init_Ext_Interrupt(const uint8_t ext_interrupt_id)  
{
	ext_interrupt_ctrl_t *cur_ext_intp_ctrl_ptr;
    uint16_t ret_status;	 
	uint8_t ext_interrupt_id_io_ch, ext_interrupt_func_mode ;
	
	if(ext_interrupt_id >= MAX_NUM_EXT_INTERRUPTS)
	{
	       sys_error_or_warning_flag = ERR_DEV_CH_ID_EXCEEDS;
	       Error_or_Warning_Proc("13.01.01", ERROR_OCCURED, sys_error_or_warning_flag);
		   return sys_error_or_warning_flag;
	}		   
	cur_ext_intp_ctrl_ptr = ext_interrupt_ctrl + ext_interrupt_id;
    switch(ext_interrupt_id)
    {
        case CH_ID_00:
	       switch(cur_ext_intp_ctrl_ptr->ext_interrupt_func_mode)
		   {
			   case IO_FUNC_MODE_01:
			       ext_interrupt_id_io_ch = IO_CH_16;
			   break;
			   case IO_FUNC_MODE_03:
                   ext_interrupt_id_io_ch = IO_CH_01; 
               break;
               default:
                  sys_error_or_warning_flag = ERR_NON_GPIO_FUNC_SET;
	              Error_or_Warning_Proc("13.01.02", ERROR_OCCURED, sys_error_or_warning_flag);
		          return sys_error_or_warning_flag;    			   
		   }          
        break;
        case CH_ID_01:
		   switch(cur_ext_intp_ctrl_ptr->ext_interrupt_func_mode)
		   {
			   case IO_FUNC_MODE_02:
			      ext_interrupt_id_io_ch = IO_CH_14; 
			   break;
			   case IO_FUNC_MODE_03:
                   ext_interrupt_id_io_ch = IO_CH_03; 
               break;
               default:
                  sys_error_or_warning_flag = ERR_NON_GPIO_FUNC_SET;
	              Error_or_Warning_Proc("13.01.03", ERROR_OCCURED, sys_error_or_warning_flag);
		          return sys_error_or_warning_flag;    			   
		   } 
        break;
        case CH_ID_02:
		   switch(cur_ext_intp_ctrl_ptr->ext_interrupt_func_mode)
		   {
			   case IO_FUNC_MODE_02:
			      ext_interrupt_id_io_ch = IO_CH_15; 
			   break;
			   case IO_FUNC_MODE_03:
                   ext_interrupt_id_io_ch = IO_CH_07; 
               break;
               default:
                  sys_error_or_warning_flag = ERR_NON_GPIO_FUNC_SET;
	              Error_or_Warning_Proc("13.01.04", ERROR_OCCURED, sys_error_or_warning_flag);
		          return sys_error_or_warning_flag;    			   
		   }
        break;
        case CH_ID_03:
		   switch(cur_ext_intp_ctrl_ptr->ext_interrupt_func_mode)
		   {
			   case IO_FUNC_MODE_01:
			      ext_interrupt_id_io_ch = IO_CH_20; 
			   break;	  
			   case IO_FUNC_MODE_02:
			      ext_interrupt_id_io_ch = IO_CH_30; 
			   break;
			   case IO_FUNC_MODE_03:
                   ext_interrupt_id_io_ch = IO_CH_09; 
               break;
               default:
                  sys_error_or_warning_flag = ERR_NON_GPIO_FUNC_SET;
	              Error_or_Warning_Proc("13.01.05", ERROR_OCCURED, sys_error_or_warning_flag);
		          return sys_error_or_warning_flag;    			   
		   }	      
        break;                    		
    }
	if(ext_interrupt_id_io_ch == IO_CH_20)
	{
		ext_interrupt_func_mode = IO_FUNC_MODE_03;
	}
	else
	{
		ext_interrupt_func_mode = cur_ext_intp_ctrl_ptr->ext_interrupt_func_mode;
	}
	if(cur_ext_intp_ctrl_ptr->ext_interrupt_sense >= EXT_INTERRUPT_SENSE_NA)
	{
		 sys_error_or_warning_flag = ERR_FORMAT_INVALID;
		 Error_or_Warning_Proc("13.01.06", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag; 
	}
	if((ret_status = Non_GPIO_Func_Set(ext_interrupt_id_io_ch, ext_interrupt_func_mode )) != SUCCESS)
	{
	     sys_error_or_warning_flag = ERR_EXT_INTERRUPT_INIT;
	     Error_or_Warning_Proc("13.01.07", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	EXTINT |= (1 << ext_interrupt_id); 	
	switch(cur_ext_intp_ctrl_ptr->ext_interrupt_sense)
	{
		case EXT_INTERRUPT_LOW_LEVEL:
		   EXTMODE &= ~(1 << ext_interrupt_id);
		   EXTPOLAR &= ~(1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_HIGH_LEVEL:
		    EXTMODE &= ~(1 << ext_interrupt_id);
			EXTPOLAR |= (1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_FALLING_EDGE:
		    EXTMODE |= (1 << ext_interrupt_id);
			EXTPOLAR &= ~(1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_RISING_EDGE:
		    EXTMODE |= (1 << ext_interrupt_id);
			EXTPOLAR |= (1 << ext_interrupt_id);
		break;
	} 
    if((ret_status =  Init_Interrupt(INTP_REQ_EINT0 + ext_interrupt_id)) != SUCCESS)
	{
		 sys_error_or_warning_flag = ERR_INTERRUPT_INIT;
		 Error_or_Warning_Proc("13.01.08", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}      	
    return SUCCESS;  
}

/*------------------------------------------------------------*
FUNCTION NAME  : Init_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Init_Interrupt(const uint8_t interrupt_request_src)	  
{
	interrupt_request_ctrl_t *cur_intp_req_ctrl_ptr;
	
	if(interrupt_request_src >= NUM_INTP_REQ_SRCS)
	{
		 sys_error_or_warning_flag = ERR_INTERRUPT_REQ_SRCS_EXCEEDS;
		 Error_or_Warning_Proc("13.02.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
  cur_intp_req_ctrl_ptr = interrupt_request_ctrl + interrupt_request_src;
  if((isr_vector_irq_alloc & (1 << cur_intp_req_ctrl_ptr->vector_irq_slot)) != 0)
  {
      sys_error_or_warning_flag = ERR_IRQ_VECTOR_ALREADY_ALLOC;
		  Error_or_Warning_Proc("13.02.02", ERROR_OCCURED, sys_error_or_warning_flag);
		  return sys_error_or_warning_flag;
  }
	VICIntEnClr |= (1 << interrupt_request_src);
	switch(cur_intp_req_ctrl_ptr->interrupt_type)
	{
		case INTERRUPT_REQ_VECTOR_IRQ:
		   //IRQ
           VICIntSelect &= ~(1 << interrupt_request_src);
		   switch(cur_intp_req_ctrl_ptr->vector_irq_slot)
		   {
		    	case VECTOR_SLOT_00:
			        VIC_VECTOR_ADDR(0) = cur_intp_req_ctrl_ptr->isr_vector_irq;
			        VIC_VECTOR_CTRL(0) = (1<<5) | interrupt_request_src;
			    break; 
			    case VECTOR_SLOT_01:
			       VIC_VECTOR_ADDR(1) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(1) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_02:
			      VIC_VECTOR_ADDR(2) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(2) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_03:
			       VIC_VECTOR_ADDR(3) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(3) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_04:
			      VIC_VECTOR_ADDR(4) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(4) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_05:
			       VIC_VECTOR_ADDR(5) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(5) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_06:
			       VIC_VECTOR_ADDR(6) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(6) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_07:
			      VIC_VECTOR_ADDR(7) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(7) = (1<<5) | interrupt_request_src ;
			    break;
			    case VECTOR_SLOT_08:
			      VIC_VECTOR_ADDR(8) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(8) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_09:
			      VIC_VECTOR_ADDR(9) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(9) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_10:
			      VIC_VECTOR_ADDR(10) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(10) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_11:
			       VIC_VECTOR_ADDR(11) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(11) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_12:
			       VIC_VECTOR_ADDR(12) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(12) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_13:
			       VIC_VECTOR_ADDR(13) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			       VIC_VECTOR_CTRL(13) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_14:
			      VIC_VECTOR_ADDR(14) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(14) = (1<<5) | interrupt_request_src;
			    break;
			    case VECTOR_SLOT_15:
			      VIC_VECTOR_ADDR(15) =  cur_intp_req_ctrl_ptr->isr_vector_irq;
			      VIC_VECTOR_CTRL(15) = (1<<5) | interrupt_request_src;
			    break;
			    default:
			       sys_error_or_warning_flag = ERR_IRQ_VECTOR_SLOT;
		           Error_or_Warning_Proc("13.06.03", ERROR_OCCURED, sys_error_or_warning_flag);
		          return sys_error_or_warning_flag;
		    }
			VICIntSelect &= ~(1 << interrupt_request_src);
		break;
        case INTERRUPT_REQ_FIQ:	
            VICIntSelect |= (1 << interrupt_request_src);	
        break;
        case INTERRUPT_REQ_NON_VECTOR_IRQ:
		    VICDefVectAddr = (uint32_t)ISR_Non_Vector_IRQ;
        break;
        case INTERRUPT_REQ_NA:
        break;
        default:
              sys_error_or_warning_flag = ERR_FORMAT_INVALID;
		      Error_or_Warning_Proc("13.06.04", ERROR_OCCURED, sys_error_or_warning_flag);
		      return sys_error_or_warning_flag;		  
	}	 
    VICIntEnable |= (1 << interrupt_request_src); 
    isr_vector_irq_alloc |= (1 << cur_intp_req_ctrl_ptr->vector_irq_slot); 
    return SUCCESS;  
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_0

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.03

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_0(void) __irq
{
	uint16_t ret_status;
	
	if((interrupt_request_ctrl + INTP_REQ_EINT0)->same_triggered_irqs_while_proc_isr_flag == STATE_YES)
	{
		EXTINT =  (1 << 0); 	    
	}
	/* --------------------   USER_CODE - BEGIN -------------- */
	 if((ret_status = Ext_Interrupt_0_Proc()) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("13.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
	 } 
	/* --------------------   USER_CODE - END ---------------- */
	if((interrupt_request_ctrl + INTP_REQ_EINT0)->same_triggered_irqs_while_proc_isr_flag == STATE_NO)  
	{
		if((interrupt_request_ctrl + INTP_REQ_EINT0)->next_triggered_irqs_while_proc_isr_flag == STATE_YES)
		{
	    	EXTINT =  (1 << 0); 
		}
		else 
	    {
		    EXTINT |=  (1 << 0); 	
	    }
	}
	 VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_1

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.04

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_1(void) __irq
{
	uint16_t ret_status;
	
	if((interrupt_request_ctrl + INTP_REQ_EINT1)->same_triggered_irqs_while_proc_isr_flag == STATE_YES)
	{
		EXTINT =  (1 << 1); 	    
	}
	/* --------------------   USER_CODE - BEGIN -------------- */
	 if((ret_status = Ext_Interrupt_1_Proc()) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("13.04.01", ERROR_OCCURED, sys_error_or_warning_flag);
	 }
	/* --------------------   USER_CODE - END ---------------- */
	if((interrupt_request_ctrl + INTP_REQ_EINT1)->same_triggered_irqs_while_proc_isr_flag == STATE_NO)  
	{
		if((interrupt_request_ctrl + INTP_REQ_EINT1)->next_triggered_irqs_while_proc_isr_flag == STATE_YES)
		{
	    	EXTINT =  (1 << 1); 
		}
		else 
	    {
		    EXTINT |=  (1 << 1); 	
	    }
	}
	VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_2

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.05

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_2(void) __irq
{
	uint16_t ret_status;
	
	if((interrupt_request_ctrl + INTP_REQ_EINT2)->same_triggered_irqs_while_proc_isr_flag == STATE_YES)
	{
		EXTINT =  (1 << 2); 	    
	}
	/* --------------------   USER_CODE - BEGIN -------------- */
	 if((ret_status = Ext_Interrupt_2_Proc()) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("13.05.01", ERROR_OCCURED, sys_error_or_warning_flag);
	 }	
	/* --------------------   USER_CODE - END ---------------- */
	if((interrupt_request_ctrl + INTP_REQ_EINT2)->same_triggered_irqs_while_proc_isr_flag == STATE_NO)  
	{
		if((interrupt_request_ctrl + INTP_REQ_EINT2)->next_triggered_irqs_while_proc_isr_flag == STATE_YES)
		{
	    	EXTINT =  (1 << 2); 
		}
		else 
	    {
		    EXTINT |=  (1 << 2); 	
	    }
	 }
	 VICVectAddr = 0;
}


/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_3

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.06

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_3(void) __irq
{
	uint16_t ret_status;
	
	if((interrupt_request_ctrl + INTP_REQ_EINT3)->same_triggered_irqs_while_proc_isr_flag == STATE_YES)
	{
		EXTINT =  (1 << 3); 	    
	}
	/* --------------------   USER_CODE - BEGIN -------------- */
	 if((ret_status = Ext_Interrupt_3_Proc()) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("13.06.01", ERROR_OCCURED, sys_error_or_warning_flag);
	 }		 
	/* --------------------   USER_CODE - END ---------------- */
	if((interrupt_request_ctrl + INTP_REQ_EINT3)->same_triggered_irqs_while_proc_isr_flag == STATE_NO)  
	{
		if((interrupt_request_ctrl + INTP_REQ_EINT3)->next_triggered_irqs_while_proc_isr_flag == STATE_YES)
		{
	    	EXTINT =  (1 << 3); 
		}
		else 
	    {
		    EXTINT |=  (1 << 3); 	
	    }
	 }
	 VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Non_Vector_IRQ

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.07

BUGS           :    
-*------------------------------------------------------------*/
void ISR_Non_Vector_IRQ(void) __irq
{
  	VICVectAddr = 0;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
