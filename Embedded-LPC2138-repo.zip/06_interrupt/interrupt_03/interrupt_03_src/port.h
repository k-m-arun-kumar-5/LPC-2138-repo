
/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

/* ---------------------- macro defination ------------------------------------------------ */
	

/* ---------------------- data type defination -------------------------------------------- */
typedef enum 
{
 	INTERNAL_ERROR_LED_IO_CH = (IO_CH_10), LED_BLINK_IO_CH = (IO_CH_02)
} io_ch_map_op_ch_t;
 
/* -------------------- public variable declaration --------------------------------------- */
 
/* -------------------- public function declaration --------------------------------------- */

 
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
