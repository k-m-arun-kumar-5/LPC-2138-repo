/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
 
uint16_t appl_error_or_warning_flag = NO_ERROR ;
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_error_or_warning_flag = NO_ERROR;		
		break;
		default:
		   appl_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_error_or_warning_flag);
		   return appl_error_or_warning_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Appl_Proc(void)
{		
    uint16_t ret_status;
	
	switch(cur_data_id) 
	{	
        case DATA_ID_LED_BLINK:
		break;
		default:
		    appl_error_or_warning_flag = ERR_CUR_DATA_ID_INVALID;
		    Error_or_Warning_Proc("11.02.05", ERROR_OCCURED, appl_error_or_warning_flag);
		    return appl_error_or_warning_flag;
	} 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_Init(const void *const data_ptr)
{	
    uint16_t ret_status;	
	
	if((ret_status =  Next_Data_Conf_Parameter(DATA_ID_LED_BLINK)) != SUCCESS)
	{
		 appl_error_or_warning_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	if((ret_status = Init_Ext_Interrupt(CH_ID_01)) != SUCCESS) 
	{
		 appl_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("11.03.02", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	if((ret_status = Init_Ext_Interrupt(CH_ID_02)) != SUCCESS) 
	{
		 appl_error_or_warning_flag = ERR_EXT_INTERRUPT_PROC;
		 Error_or_Warning_Proc("11.03.03", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.04  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_HW_Init(void)
{
    uint16_t ret_status ;
	
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(INTERNAL_ERROR_LED_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(LED_BLINK_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	return SUCCESS; 
}

#ifdef TIMER_MOD_ENABLE 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_0_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.05  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_0_Timeout_Proc(const uint8_t timer_cur_run_id)
{
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
  timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	uint16_t ret_status;
	
	if(timer_cur_run_id >= NUM_TIMER_AND_COUNTER_IDS)
	{
		appl_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.05.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + timer_cur_run_id;
	cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_00;
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Timer_1_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.06  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_1_Timeout_Proc(const uint8_t timer_cur_run_id)
{
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
  timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	uint16_t ret_status; 
  uint8_t port, port_pin; 
  static uint8_t cur_state_blink_led = STATE_LOW;	
  
	if(timer_cur_run_id >= NUM_TIMER_AND_COUNTER_IDS)
	{
		appl_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.06.01", ERROR_OCCURED, appl_error_or_warning_flag);
		return appl_error_or_warning_flag;
	}
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + timer_cur_run_id;
  cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_01;
	switch(timer_cur_run_id)
	{
		case TIMER_ID_LED_BLINK:
        port = LED_BLINK_IO_CH / NUM_PINS_PER_PORT;
	     port_pin = LED_BLINK_IO_CH % NUM_PINS_PER_PORT;
		   switch(cur_state_blink_led)
	     {
		      case STATE_HIGH:
		         *io_port_clr_ptr[port] |= (1 << port_pin); 
                 cur_state_blink_led = STATE_LOW; 	
			  #ifdef TRACE
                Print("\r TRA: Timeout - BLINK LED OFF ");
              #endif 
		       break;
		       case STATE_LOW:
  	               *io_port_set_ptr[port] |= (1 << port_pin);	
    		       cur_state_blink_led = STATE_HIGH; 
			  #ifdef TRACE
                Print("\r TRA: Timeout - BLINK LED ON ");
              #endif    
           break;         	 
        } 
        // commented for to timer expiry service = Interrupt, then led is not flashed ON appropiately. 
    /*  #ifdef TRACE
          Print("\r TRA: Timeout count: %u",cur_timer_or_counter_status_ptr->cur_num_timeouts + 1);
      #endif */
      /*switch(cur_state_blink_led)
      {
        case STATE_LOW:
           if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_HIGH)) != SUCCESS)
           {
              appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.02", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           }  
           cur_state_blink_led = STATE_HIGH;
        break;
        case STATE_HIGH:   
           if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_LOW)) != SUCCESS)
           {
              appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.03", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           }  
           cur_state_blink_led = STATE_LOW;
         break;
      } */
      /* commented due to proteus 8.3 does not toggle LED_BLINK_IO_CH using ^= operator
         but in keil uvision 5, debug session and view GPIO, it toggles LED_BLINK_IO_CH */        
          /* if((ret_status = IO_Channel_Write(LED_BLINK_IO_CH, STATE_TOGGLE)) != SUCCESS)
          {
              appl_error_or_warning_flag = ERR_IO_CH_WRITE;
		          Error_or_Warning_Proc("11.06.04", ERROR_OCCURED, appl_error_or_warning_flag);
		          return appl_error_or_warning_flag;     
           } */
	  break;       
	 }
    return SUCCESS;	
}

#endif


#ifdef INTERRUPT_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_0_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.07  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_0_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_1_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.08  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_1_Proc(void)
{
  timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
  
  cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_01;
  if(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id == TMR_OR_COUNTER_STOP_STATE)
  {
	  #ifdef TRACE 
	    UART_Transmit_Str(TRACE_UART_CH_ID, "\r Timer Trigger to run ");
	  #endif
      Timer_Run(CH_ID_01, TIMER_ID_LED_BLINK );
  }
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_2_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.09  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_2_Proc(void)
{
   timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
  
   cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_01;
   if(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id != TMR_OR_COUNTER_STOP_STATE)
   {
	 #ifdef TRACE 
	    UART_Transmit_Str(TRACE_UART_CH_ID, "\r Timer Trigger to stop");
	  #endif
      Timer_Stop(CH_ID_01);      
   }
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_3_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.10  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_3_Proc(void)
{
	return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
